//定义一个数组,1~5,打乱排列
import java.util.Random;

public class Demo12 {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] arr = {1,2,3,4,5,6,7,8,9};
        // 此处初始化随机数,使用随机数范围进行排序

        for(int i = arr.length - 1;i > 0;i--){
            int hjm = rand.nextInt(i + 1);
            int temp = arr[i];
            arr[i] = arr[hjm];
            arr[hjm] = temp;
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }

    }
}