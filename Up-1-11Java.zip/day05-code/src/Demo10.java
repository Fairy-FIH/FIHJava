import java.util.Random;

public class Demo10 {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] arr = {1,2,3,4,5,6,7,8,9,10};
        for(int i = arr.length - 1;i > 0;i--){
            int r = rand.nextInt(i + 1);
            int temp = arr[i];
            arr[i] = arr[r];
            arr[r] = temp;
        }
        System.out.println("打乱后的数组：");
        for (int j : arr) {
            System.out.print(j);
        }
    }
}