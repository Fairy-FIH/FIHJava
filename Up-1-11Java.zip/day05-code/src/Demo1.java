public class Demo1 {
    public static void main(String[] args) {
//        for(int i = 1;i <= 100;i++){
//            int num = i % 10;
//            int num2 = i / 10;
//            if(i % 7 == 0 || num == 7 || num2 == 7){
//                System.out.println("过");
//            }else {
//                System.out.println(i);
//            }
//        }
//
//
//        int i = 0;
//        int num = 100;
//        while(i < num){
//            i++;
//            boolean num1 = i % 10 == 7;
//            boolean num2 = i / 10 == 7;
//            boolean num3 = i % 7 == 0;
//            int num4 = num1 || num2 || num3 ? 1 : 0;
//            switch(num4){
//                case 1:
//                    System.out.println("过");
//                    break;
//                case 0:
//                    System.out.println(i);
//                    break;
//            }
//        }


//
//
//
//        for (int i = 1; i <= 100; i++) {
//            if(i % 7 == 0 || i % 10 == 7 || i / 10 % 10 == 7){
//                System.out.println("过");
//                continue;
//            }
//            System.out.println(i);
//        }
//
//
//
//
//
//
//
//






 for(int i = 1;i <= 9;i++){
     for(int j = 1;j < i;j++){
         System.out.print(j + "x" + i +"=" + i * j +"\t");
     }
     System.out.println();
 }




























    }
}


