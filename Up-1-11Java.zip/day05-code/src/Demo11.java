//需求:定义一个数组，存入1~5。要求打乱数组中所有数据的顺序。

import java.util.Random;

public class Demo11 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5};
        Random rand = new Random();
        for(int i = arr.length - 1;i > 0;i--){
            int r = rand.nextInt(i + 1);
            int temp = arr[i];
            arr[i] = arr[r];
            arr[r] = temp;

        }
        for(int i = 0;i < arr.length;i++){
            System.out.println(arr[i]);
        }
    }
}