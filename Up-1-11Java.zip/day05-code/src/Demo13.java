public class Demo13 {
    public static void main(String[] args) {

//        int a;
//        int a = new int (123);
//        这个相当于在堆中存入"哈基米",一旦方法结束,但"哈基米"在堆中的内存指引不会消失,还可以在其他方法中被引用?
//        String b = "哈压库";
//        这个相当于在栈中存入"哈压库",一旦方法结束,"哈压库"立马被栈帧释放,且别的方法中也不能引用这个?
//        这样操作相当于b在当前方法中有效,是临时的,一旦该方法进程结束,b里面的值就没了.而a因为直接在堆中建立的内存块且存入的值,即使方法结束也不会消失?
//        我猜想一下,那像a这样在堆中建值的操作是一开始就在main(程序主入口)存好的,而main方法只需要引用其他的方法返回的操作运行就可以了,其他方法直接调用堆中存入的内存地址就行了.b这种只能在一个方法内使用,a这种可以在所有方法中使用?

        int[] arr = {11,22};
        int[] arr2 = arr;

        System.out.println(arr[0]);
        System.out.println(arr2[0]);

        arr2[0] = 33;

//        System.out.println(arr[0]);
//        System.out.println(arr2[0]);
//        for (int i = 0; i < arr.length; i++) {
//            System.out.println(arr[i]);
//        }
//        System.out.println("______________");
//        for (int i = 0; i < arr2.length; i++) {
//            System.out.println(arr2[i]);
//        }
        System.out.println(arr);
        System.out.println(arr2);
    }
}