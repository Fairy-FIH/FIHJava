import java.util.Random;

public class Test3 {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] arr = new int[10];
        int sum = 0;
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            int number = rand.nextInt(1,101);
            arr[i] = number;
            System.out.print(arr[i] + " ");
            sum = sum + arr[i];
        }
        System.out.print("\n");
        int svg = sum / arr.length;
        System.out.println("总数为:" + sum);
        System.out.println("平均值为:" + (double)svg);
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] < svg){
                count++;
            }
        }
        System.out.println("比平均数小的有" + count + "个");
    }
}

