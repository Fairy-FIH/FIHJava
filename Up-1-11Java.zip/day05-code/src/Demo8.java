public class Demo8{
    public static void main(String[] args){
        int[] arr = {33,5,22,44,55};
//            int no1 = arr[0] > arr[1] ? arr[0] : arr[1];
//            int no2 = arr[2] > arr[3] ? arr[2] : arr[3];
//            int no3 = no1 > no2 ? no1 : no2;
//            int no4 = no3 > arr[4] ? no3 : arr[4];
//        System.out.println(no4);


        int min = arr[0];

        for (int i = 0; i < arr.length; i++){
            if (arr[i] < min){
                min = arr[i];
            }
        }
        System.out.println(min);



    }
}