import java.util.Random;

public class Demo9 {
    public static void main(String[] args){
        Random rand = new Random();
        int sum = 0;
        int count = 0;
        int[] arr = new int[10];
        for(int i = 0;i < arr.length;i++){
            int hjm = rand.nextInt(1,101);
            arr[i] = hjm;
            sum += arr[i];
            System.out.print(arr[i] + " ");
        }
        System.out.println("所有数之和为:" + sum);
        double pjs = (double)sum / arr.length;
        System.out.println("平均数为:" + pjs);
        for(int i = 0;i < arr.length;i++){
            if (arr[i] < pjs){
                count++;
            }
        }
        System.out.println("比平均数小的有:" + count);
    }
}