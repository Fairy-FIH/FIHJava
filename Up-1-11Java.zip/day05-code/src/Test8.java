public class Test8 {
    public static void main(String[] args){
        int[] arr = {1,2,3,4,5,6,7,8,9};
        for(int i = 0; i < arr.length;i++){
            System.out.print(arr[i]);
        }
        System.out.println("  ");
//        for(int i = 0,j = arr.length - 1;i <  j;i++,j--){
//            int temp = arr[i];
//            arr[i] = arr[j];
//            arr[j] = temp;
//        }
//        for(int i = 0;i < arr.length;i++){
//            System.out.print(arr[i]);
//        }

        int[] arr2 = new int[arr.length];
        for(int i = 0; i < arr2.length;i++){
            System.out.print(arr2[i]);
        }
        for(int i = arr.length,j = 0;i > j;j++,i--){
            arr2[j] = arr[i];
        }
        for(int i = 0; i < arr.length;i++){
            System.out.print(arr2[i]);
        }




    }
}