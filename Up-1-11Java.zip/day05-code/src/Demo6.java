import java.util.Scanner;
import java.util.Random;

public class Demo6 {
    public static void main(String[] args){
        int[] nianling = {11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36};
        String[] xingming = {"哈基米","叮咚鸡","大狗叫"};
        double[] shengao = {163.1,170.5,160};
//        xingming[1] = "阿西嘎";
//        System.out.println(xingming[1]);


//        for(int i = 0;i < nianling.length;i++){
//            System.out.println(nianling[i]);
//        }
//        System.out.println(nianling.length);

        for (int i = 0; i < shengao.length; i++) {

        }

    }
}