import java.util.Random;
import java.util.Scanner;

public class Demo4 {
    public static void main(String[] args){
        Random rd = new Random();
        Scanner sc = new Scanner(System.in);
//        int zhen = 0;
//        int jian = 0;
//        int ling = 0;
        int s = rd.nextInt(0,101);
        int count = 0;
//        String hjm = "";

//        for(int i = 1; i <= 100; i++){
//
////            System.out.println(s);
//
//            if(s <= 100 && s >= 50){
//                jian++;
//            } else if (s > 0 && s < 50) {
//                zhen++;
//            } else if (s == 0) {
//                ling++;
//            }
//
//        }
        System.out.println("请输入这个值");


        while(true){
//            System.out.println("请输入这个值");
            int x = sc.nextInt();
            if(x < s){
                System.out.println("小了");
                count++;
            }else if(x ==  s){
                System.out.println("正确");
                count++;
                break;
            }else if(x > s){
                System.out.println("大了");
                count++;
            }

        }
        System.out.println("-------------------");
        System.out.println("\t" + "游戏结束!");
        System.out.println("共猜测" + count + "次");

//        switch (hjm){
//            case "hjm":
//                System.out.println("大于等于50的,小于等于100的有:" + jian + '个');
//                System.out.println("大于0的,小于50的有:" + zhen + '个');
//                System.out.println("等于0的数字有" + ling + '个');
//                break;
//        }
//


    }
}