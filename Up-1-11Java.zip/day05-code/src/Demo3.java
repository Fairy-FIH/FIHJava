import java.util.Scanner;
public class Demo3{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("输入这个值");
        int a = sc.nextInt();
        boolean b = true;

        for (int i = 2;i < a;i++){
            if(a % i == 0){
                b = false;
                break;
            }
        }
        if (b){
            System.out.println("是质数");
        }else {
            System.out.println("不是质数");
        }
    }
}