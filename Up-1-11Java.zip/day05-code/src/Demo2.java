import java.util.Scanner;

public class Demo2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入一个值");
        int x = sc.nextInt();

        for(int i = 0;i <= x;i++){
            if(i * i == x){
                System.out.println("\t" + x + "平方根是" + i);
                break;
            } else if (i * i > x) {
                System.out.println("\t" + x + "平方根是" + (i - 1) );
                break;
            }
        }
    }
}