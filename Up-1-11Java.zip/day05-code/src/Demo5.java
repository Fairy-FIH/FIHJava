import java.util.Scanner;
import java.util.Random;
public class Demo5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int count = 0;
        System.out.println(".....计数器已加载完成");
        int number = rand.nextInt(1,101);
        System.out.println(".....随机数生成已完成");
        System.out.println(".....程序已完成初始化");
        System.out.println("请输入猜测的值:");
        while(true){
            int x = sc.nextInt();
            count++;
            if(count == 5){
                System.out.println("触发保底,猜中啦!");
                break;
            }
            if(x == number){
                System.out.println("猜测正确");
                break;
            } else if (x < number) {
                System.out.println("猜测值小了");
            } else if (x > number) {
                System.out.println("猜测值大了");
            }
        }
        System.out.println("....................");
        System.out.println("经程序统计,您共计猜测" + count + "次");
    }
}