public class Test2 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7,8,9,10};
        for(int i = 0; i<arr.length;i++){
            int yuanben = arr[i];
//            System.out.println(arr[i]);
//            if(arr[i] % 2 ==1){
//                arr[i] = arr[i] * 2;
//                System.out.println("是奇数的:" + arr[i] + "\t当前原本数字是:" + yuanben);
//            }else{
//                arr[i] = arr[i] / 2;
//                System.out.println("是偶数的:" + arr[i] + "\t当前原本数字是:" + yuanben);
//            }

            boolean flag = arr[i] % 2 ==0 ? true : false;
            if (flag){
                arr[i] = arr[i] / 2;
                System.out.println("是奇数的:" + arr[i] + "\t当前原本数字是:" + yuanben);
            }else {
                arr[i] = arr[i] * 2;
                System.out.println("是偶数的:" + arr[i] + "\t当前原本数字是:" + yuanben);
            }


        }

    }
}