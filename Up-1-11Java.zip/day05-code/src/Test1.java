public class Test1 {
    public static void main(String[] args){
        int[] arr = {12,3,4,5,6,7,8,9,10};
        int count = 0;
        for(int i = 0;i < arr.length;i++){
//            System.out.println(arr[i]);

            if(arr[i] % 3 ==0){
                count++;
                System.out.println(arr[i]);
            }


        }
        System.out.println("能被3整除的数字有" + count + "个");
    }
}