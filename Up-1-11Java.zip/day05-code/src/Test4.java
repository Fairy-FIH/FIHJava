/*需求:生成10个1~100之间的随机数存入数组。1)求出所有数据的和
2)求所有数据的平均数3)统计有多少个数据比平均值小*/
import java.util.Random;
public class Test4 {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] arr = new int [10];
        int sum = 0;
        int count = 0;

        for(int i = 0;i < arr.length;i++){
            int suiji = rand.nextInt(1,101);
            arr[i] = suiji;
            sum = sum + arr[i];
        }
        int avg = sum /arr.length;
        for(int i = 0;i < arr.length;i++){
            if(arr[i] < avg){
                count++;
            }
        }
        System.out.println("总数为:" + sum);
        System.out.println("平均数为:" + avg);
        System.out.println("小于平均数的数字共计" + count + "个");
    }
}