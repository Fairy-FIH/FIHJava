import java.util.Scanner;

public class Test10 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("欢迎致电中国移动(10086)");
        int a = sc.nextInt();

//        if(!sc.hasNextInt()){
//            System.out.println("没有此项操作");
//            sc.close();
//            return;
//        }


        if (!sc.hasNextInt()) {
            System.out.println("输入错误！请输入有效的数字。");
            sc.close();
            return;
        }

        if (a == 10086){
            System.out.println("请选择以下服务");
            System.out.println("1/查询套餐");
            System.out.println("2/查询余额");
            System.out.println("3/查询地点");
            System.out.println("4/退出服务");

            System.out.println("请输入查询业务");
            int b = sc.nextInt();
            switch(b){
                case 1 -> System.out.println("正在查询套餐ing");
                case 2 -> System.out.println("正在查询余额ing");
                case 3 -> System.out.println("正在查询地点ing");

            }

        }else{
            System.out.println("已退出服务");
        }

    }
}