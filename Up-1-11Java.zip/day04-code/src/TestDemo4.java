//需求:给定两个整数，被除数和除数(都是正数，且不超过int的范围)将两数相除，要求不使用乘法、除法和 % 运算符。得到商和余数。


public class TestDemo4 {
    public static void main(String[] args) {
        int a = 10;
        int b = 3;
        int c = 0;
        int d = a;

        while(d >= b){
            d = d - b;
            c++;
        }
        System.out.println(c);
        System.out.println(d);
    }
}