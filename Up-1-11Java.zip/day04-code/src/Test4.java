import java.util.Scanner;

public class Test4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入数字");
        int a = sc.nextInt();
//
//
//        if (a == 100){
//            System.out.println("你居然考了100!打一顿");
//        } else if (a <= 90) {
//            System.out.println("100都考不到,打两顿");
//        } else if (a <= 80) {
//            System.out.println("100都考不到,打两顿");
//        }else if (a < 70) {
//            System.out.println("打死算了");
//        }

        if(a < 1 || a > 100){
            System.out.println("你在看看呢");
        } else if (a < 100 && a >= 95) {
            System.out.println("奖励你自行车");
        } else if (a < 94 && a >= 90) {
            System.out.println("去游乐场玩!");
        } else if (a < 89 && a >= 80) {
            System.out.println("奖励你高达机器人");
        } else if (a < 79) {
            System.out.println("吃皮鞭吧!!!!!");
        }


    }

}