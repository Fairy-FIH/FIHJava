/* 键盘录入两个数字,表示一个范围。
统计这个范围中
既能被9整除，又能被4整除数字有多少个? */


import java.util.Scanner;

public class DemoTest1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入数字");
        int a = sc.nextInt();
        System.out.println("请输入数字");
        int b = sc.nextInt();

        int cout = 0;

        int max = a > b ? a : b;
        int min = a < b ? a : b;

        for (int i =min;i <=max;i++){
            if(i % 4 == 0 && i % 9 == 0){
                System.out.println(i);
                cout++;
            }
        }
        System.out.println(cout);


    }
}