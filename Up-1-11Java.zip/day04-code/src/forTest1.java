/*需求:键盘录入两个数字，表示一个范围。
统计这个范围中。
既能被6整除，又能被5整除数字有多少个?*/

import java.util.Scanner;

public class forTest1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("第一个值");
        int start = sc.nextInt();
        System.out.println("第二个值");
        int end = sc.nextInt();

        int cout = 0;

        int max = start > end ? start : end;
        int min = start < end ? start : end;

        for(int i= min;i <= max;i++){

            if(i % 6 == 0 && i % 5 ==0){
                System.out.println("能被整除的是:" + "\t" +i);
                cout++;
            }
        }
        System.out.println("共计" + cout + "个");

    }
}