package Test;

import java.util.Scanner;

public class Test9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("欢迎拨打东方航空电话(95530)");
        int Phone = sc.nextInt();

        if (Phone == 95530) {
            System.out.println("查询业务:");
            System.out.println("1-机票服务");
            System.out.println("2-机票预订");
            System.out.println("3-机票改签");
            System.out.println("4-退出服务");

            System.out.println(" ");

            System.out.println("请第二次输入数字");
            int b = sc.nextInt();
            switch (b) {
                case 1 -> System.out.println("正在办理机票业务");
                case 2 -> System.out.println("正在执行机票预订");
                case 3 -> System.out.println("正在为您机票改签");
                case 4 -> System.out.println("已退出服务，感谢您的使用！");
                default -> System.out.println("已退出服务，感谢您的使用！");
            }
        }else {
            System.out.println("号码错误,已退出服务");
        }

    }
}