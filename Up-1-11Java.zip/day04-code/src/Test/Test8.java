package Test;

import java.util.Scanner;

public class Test8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("请输入星期:");
        String s = sc.nextLine();
        // 一号文本
//        switch (s) {
//            case "1":
//                System.out.println("星期一-工作日-switch");
//
//            case "2":
//                System.out.println("星期二-工作日-switch");
//
//            case "3":
//                System.out.println("星期三-工作日-switch");
//
//            case "4":
//                System.out.println("星期四-工作日-switch");
//
//            case "5":
//                System.out.println("星期五-工作日-switch");
//                break;
//            case "6":
//                System.out.println("星期六-休息日-switch");
//
//            case "7":
//                System.out.println("星期日-休息日-switch");
//                break;
//            default:
//                System.out.println("非法数值");
//        }
        // 二号文本
        switch (s) {
            case "1":
            case "2":
            case "3":
            case "4":
            case "5":
                System.out.println("工作日-newswitch");
                break;
            case "6":
            case "7":
                System.out.println("休息日-newswitch");
                break;
        }
        // 三号文本
        switch (s) {
            case "1", "2", "3", "4", "5" -> System.out.println("工作日-新switch穿透语句");
            case "6", "7" -> System.out.println("休息日-新switch穿透语句");
        }

        // 四号文本
        switch (s) {
            case "1" -> System.out.println("工作日-swnew");
            case "2" -> System.out.println("工作日-swnew");
            case "3" -> System.out.println("工作日-swnew");
            case "4" -> System.out.println("工作日-swnew");
            case "5" -> System.out.println("工作日-swnew");
            case "6" -> System.out.println("休息日-swnew");
            case "7" -> System.out.println("休息日-swnew");
        }
        // 五号文本
        switch (s) {
            case "1", "2", "3", "4", "5":
                System.out.println("工作日");
                break;
            case "6", "7":
                System.out.println("休息日");
                break;
        }

        //六号文本
//        if(s == "1"){
//            System.out.println("工作日-if");
//        } else if (s == "2") {
//            System.out.println("工作日-if");
//        } else if (s == "3") {
//            System.out.println("工作日-if");
//        } else if (s == "4") {
//            System.out.println("工作日-if");
//        } else if (s == "5") {
//            System.out.println("工作日-if");
//        } else if (s == "6") {
//            System.out.println("休息日-if");
//        } else if (s == "7") {
//            System.out.println("休息日-if");
//        }
    }
}