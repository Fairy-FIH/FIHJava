package Test;

import java.util.Scanner;

public class Test1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入成绩");
        int a = sc.nextInt();

        if (a >= 100) {
            System.out.println("小红:我做你女朋友");
        }else {
            System.out.println("小红:你走开!");
        }
    }
}