package Test;

import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

//        System.out.println("输入数字");
//        int a = sc.nextInt();

        int a = 600;

        int b = sc.nextInt();

        if (b >= a){
            System.out.println("付款成功");
        }else {
            System.out.println("付款失败");
        }
    }
}