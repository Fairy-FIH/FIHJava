//需求:给你一个整数x。
//    如果x是一个回文整数，打印 true，否则，返回 false 。
//解释:回文数是指正序(从左向右)和倒序(从右向左)读都是一样的整数。
//例如，121 是回文，而 123不是

import java.util.Scanner;

public class Testdemo2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入数字");
        int a = sc.nextInt();
        int temp = a;
//        定义temp为初始缓存
        int num = 0;
//        定义num为字反过来的值;

        while(a != 0){
//            循环到a不等于0位置\开始
            int ge = a % 10;
//            定义个位数,拿个位数
            a = a / 10;
//            给a换值
            num = num * 10 + ge;
//            给拿到的值换位
        }
        System.out.println(num);
        System.out.println(num == temp);
    }
}