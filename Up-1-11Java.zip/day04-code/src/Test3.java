import java.util.Scanner;

public class Test3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("输入电影票号1~100");
        int b = sc.nextInt();

        if(b < 0 | b > 100){
            // 校验程序
            System.out.println("输入值无效");
        }else if(b % 2 == 0){
            System.out.println("偶数票,你在右边座位");
        }else {
            System.out.println("奇数票,你在左边座位");
        }
    }
}