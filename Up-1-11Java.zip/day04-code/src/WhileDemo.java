//需求:世界最高山峰是珠穆朗玛峰(8844.43米=8844430毫米)，假如我有一张足够大的纸，它的厚度是0.1毫米:请问，我折叠多少次，可以折成珠穆朗玛峰的高度?



public class WhileDemo {
    public static void main(String[] args) {
        double a = 0.1;
        double b = 8844430;
        int c = 0;
        while(a <= b){
//            System.out.println("\t" + "a的值为" + a);
            a *=2;
            c++;
            System.out.println("\t" + "a的值为" + a);
        }
        System.out.println("\t" + "共计折叠" + c + "次");

        System.out.println("--------------------------");


        int cout = 0;
        for(double i = 0.1;i <= 8844430;i *= 2){
            cout++;
            System.out.println("\t" + "i的值为" + i);
        }
        System.out.println("\t" + "共计折叠" + cout + "次");

        System.out.println("b 的值 = " + b);
        System.out.println("b 的十六进制 = " + Double.toHexString(b));
        System.out.println("b == 8844430 ? " + (b == 8844430));
    }
}