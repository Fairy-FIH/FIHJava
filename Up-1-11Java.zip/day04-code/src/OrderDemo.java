import java.util.Scanner;

public class OrderDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("你的酒量");
        int a = sc.nextInt();

//        if (a >= 2){
//            System.out.println("小伙子可以的");
//        }else if (a < 10){
//            System.out.println("啥玩意");
//        }


        String x = (a >= 2) ? "我同意了" : "";
        System.out.println(x);
    }
}