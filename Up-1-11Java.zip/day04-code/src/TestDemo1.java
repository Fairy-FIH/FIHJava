//需求:给你一个整数x。
//    如果x是一个回文整数，打印 true，否则，返回 false 。
//解释:回文数是指正序(从左向右)和倒序(从右向左)读都是一样的整数。
//例如，121 是回文，而 123不是
import java.util.Scanner;

public class TestDemo1 {
    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("输入数字");
//        int a = sc.nextInt();

//        int ge = a % 10;
//        int shi = a / 10 % 10;
//        int bai = a / 100 % 10;
//        int qian = a / 1000 % 10;
//        if(a >= 10 && a <= 9999) {
//            if (a >= 1000 && a <= 9999) {
//                if(ge == qian && shi == bai) {
//                    System.out.println("是回文");
//                }else {
//                    System.out.println("不是回文");
//                }
//            }else if (a >= 100 && a <= 999) {
//                if(ge == bai ){
//                    System.out.println("是回文");
//                }else {
//                    System.out.println("不是回文");
//                }
//            }else if (a >= 10 && a <= 99) {
//                if(ge == shi ){
//                    System.out.println("是回文");
//                }else {
//                    System.out.println("不是回文");
//                }
//            }
//        }else {
//            System.out.println("请输入4~2位数以内的值");
//        }

        int x = 101;
        int temp = x;
        int num = 0;
        while (x != 0){
            int ge = x % 10;
            x = x / 10;
            num = num * 10 +ge;
        }
        System.out.println(num);
        System.out.println(temp == num);




    }
}