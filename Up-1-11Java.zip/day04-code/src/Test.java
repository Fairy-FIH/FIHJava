import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        boolean red = true;
        boolean yellow = false;
        boolean green = false;

        if(green){
            System.out.println("Go!Go!Go!");
        }else if(yellow){
            System.out.println("Slow!");
        }else if(red){
            System.out.println("Stop!");
        }

    }
}