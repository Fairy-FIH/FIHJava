import java.util.Scanner;

public class Test6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double sp = 1000;
        System.out.println("你的会员等级是:[只能输入3.2.1.0]");
        int a = sc.nextInt();
        
        if (a < 0 || a > 3) {
            System.out.println("不合法等级");
        } else if (a == 1) {
            System.out.println("你的价格为:" + sp * 0.9);
        }else if (a == 2) {
            System.out.println("你的价格为:" + sp * 0.8);
        }else if (a == 3) {
            System.out.println("你的价格为:" + sp * 0.7);
        }else{
            System.out.println("打锤子折扣,没打你就不错了!");
        }
    }
}