public class TestDemo3 {
    public static void main(String[] args) {
        int a = 93;
        int b = 24;
        int c = 0;
        int d = a;

        while(d > b){
            d = d - b;
            c++;
        }
        System.out.println("商是" + c + "余是" + d);
    }
}