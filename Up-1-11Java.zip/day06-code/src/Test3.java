import java.util.Scanner;
public class Test3 {
    static Scanner sc = new Scanner(System.in);
    public static int he(int a,int b){
        return a + b;
    }
    public static int[] fh(){
        int a = sc.nextInt();
        int b = sc.nextInt();
        return new int[]{a,b};
    }
    public static void zg(){
        int[] bb = fh();
        int a = bb[0];
        int b = bb[1];
        System.out.println(he(a,b));
    }
    public static void main(String[] args) {
        zg();
    }
}