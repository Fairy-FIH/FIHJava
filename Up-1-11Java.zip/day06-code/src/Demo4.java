import java.util.Scanner;
public class Demo4 {
    public static int cfx1(int a,int b){
        return a * b;
    }
    public static int cfx2(int i,int j){
        return i * j;
    }

    public static void shuchu(){
        Scanner sc = new Scanner(System.in);
        System.out.println("第一个长方形-长");
        int a = sc.nextInt();
        System.out.println("第一个长方形-宽");
        int b = sc.nextInt();
        System.out.println("第二个长方形-长");
        int i = sc.nextInt();
        System.out.println("第二个长方形-宽");
        int j = sc.nextInt();
        if(cfx1(a,b) > cfx2(i,j)){
            System.out.println("第一个长方形面积大于第二个");
        }else {
            System.out.println("第二个长方形面积大于第一个");
        }
    }
    public static void main(String[] args){
        shuchu();
    }
}