//要求：
//用Scanner接收用户输入的两个整数
//定义求和方法（参考你学的两种写法任选一种）
//调用方法并输出结果
//import java.util.Scanner;
//public class Test2 {
//    public static int num(int a ,int b){
//        return a + b;
//    }
//    public static void number(){
//        Scanner sc = new Scanner(System.in);
//        int a = sc.nextInt();
//        int b = sc.nextInt();
//        System.out.println(num(a,b));
//    }
//    public static void main(String[] args) {
//        number();
//    }
//}
//
//要求：
//用Scanner输入三个整数
//定义方法：接收三个整数，返回平均值（double 类型）
//主方法中调用方法，输出 “三个数的平均值是：XXX”（保留 1 位小数）
//import java.util.Scanner;
//public class Test2 {
//    public static double hjm(double a,double b,double c){
//        return (a + b + c) / 3;
//    }
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        double a = sc.nextDouble();
//        double b = sc.nextDouble();
//        double c = sc.nextDouble();
//        System.out.println(hjm(a,b,c));
//    }
//}
//
//要求：
//用Scanner接收两个小数（double 类型）
//定义有返回值的方法（参考你的方法二），计算第一个数减第二个数的结果
//主方法中接收返回值，格式化输出结果（保留 2 位小数）
//提示：Scanner接收小数用nextDouble()，格式化输出用System.out.printf("%.2f", 结果)
//import java.util.Scanner;
//public class Test2 {
//    public static double hjm(double a,double b){
//        return a - b;
//    }
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        double a = sc.nextDouble();
//        double b = sc.nextDouble();
//        System.out.println(hjm(a,b));
//    }
//}
//
//用Scanner输入长和宽（可以是小数）
//定义两个方法：
//计算周长的方法（返回值）
//计算面积的方法（返回值）
//主方法中调用两个方法，分别输出周长和面积
import java.util.Scanner;
public class Test2 {
    public static double zhouchang(float a, float b){
         return (a + b) * 2;
    }
    public static float mianji(float a,float b){
        return a * b;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入长");
        float a = sc.nextFloat();
        System.out.println("请输入宽");
        float b = sc.nextFloat();
        System.out.println("周长为:" + zhouchang(a,b));
        System.out.println("面积为:" + mianji(a,b));
        sc.close();
    }

}



