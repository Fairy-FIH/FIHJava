import java.util.Scanner;
import java.util.Arrays;

public class Test8 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7,8,9};
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
        }
        System.out.println();
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
//        int[] num = Arrays.copyOfRange(arr,a,b);
        int[] num = arr(arr,a,b);
        System.out.println(Arrays.toString(num));
    }
    public static int[] arr(int[] arr,int a,int b){
        return Arrays.copyOfRange(arr,a,b);
    }
}

//
//
//public class Test8 {
//    public static void main(String[] args) {
//        int[] list = {1, 2, 3, 4, 5, 6, 7, 8, 9};
//        Scanner sc = new Scanner(System.in);
//        for (int i = 0; i < list.length; i++) {
//            System.out.print(list[i] + " ");
//        }
//        System.out.println();
//        int a = sc.nextInt();
//        int b = sc.nextInt();
//        int[] newarr = arr(list, a, b);
//        System.out.println(Arrays.toString(newarr));
//    }
//
//    public static int[] arr(int[] arr, int a, int b) {
//        return Arrays.copyOfRange(arr, a, b);
//    }
//}