import java.util.Scanner;
public class Demo3 {
    static Scanner sc = new Scanner(System.in);
    public static int zc(int a, int b){
        return (a + b) * 2;
    }
    public static int[] sr(){
        int a = sc.nextInt();
        int b = sc.nextInt();
        return new int[]{a,b};
    }
    public static void hjm(){
        int[] arr = sr();
        int a = arr[0];
        int b = arr[1];
        System.out.println(zc(a,b));
    }
    public static void main(String[] args) {
        hjm();
    }
}