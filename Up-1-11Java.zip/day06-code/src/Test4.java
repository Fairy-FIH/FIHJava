import java.util.Scanner;
public class Test4 {
    static Scanner sc = new Scanner(System.in);
    public static double mianji(double b){
        return (b * b) * 3.14;
    }
    public static double[] sr(){
        double b = sc.nextDouble();
        return new double[]{b};
    }
    public static void sc(){
        double[] arr = sr();
        double b = arr[0];
        System.out.println(mianji(b));
    }
    public static void main(String[] args) {
        sc();
    }
}