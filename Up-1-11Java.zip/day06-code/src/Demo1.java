public class Demo1 {
    public static void main(String[] args) {
        // 程序主入口
        num2();
        // 调用num方法,打印3
    }
    public static int[] num() {
        // 创建一个数组类型的方法名为num
        int a = 1;
        //创建int类型a为1
        int b = 2;
        // 创建int类型b为2
        int[] arr = {a,b};
        // 创建一个名为arr的int类型的数组,数组内包含{a(1),b(2)}
        return arr;
        // 返回arr的值
    }
    public static void num2() {
        // 创建一个没有返回值的num方法
        int[] hjm = num();
        // 创建一个int类型的名为hjm的数组,其调用num()方法,但因num返回值是arr的堆地址,所以int[] hjm = arr的堆内存地址
        int number = hjm[0] + hjm[1];
        // 创建一个int类型的名为number的值,其值为arr数组索引0和1,也就是1和2,相加得到3,所以number为3
        System.out.println(number);
        // 打印number的值(3)
    }

}