public class Test9 {
    public static void main(String[] args) {
        int[] arr = {10,20,30};
        System.out.println(arr[1]);
        arr(arr);
        System.out.println(arr[1]);
    }
    public static void arr(int[] arr){
        arr[1] = 200;
    }
}