//需求:定义一个方法判断数组中的某一个数是否存在，将结果返回给调用处


import java.util.Scanner;


public class Test6 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,6543,65,32,12,432,55,22,5};
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入要查询的值");
        int a = sc.nextInt();
        System.out.println(cantains(arr,a));
    }
    public static boolean cantains(int[] arr,int a){
        for(int i = 0;i< arr.length;i++){
            if(arr[i]==a){
                return true;
            }
        }
        return false;
    }
}
