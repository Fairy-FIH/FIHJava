//方法一:
//public class Test1 {
//    public static void number(int a,int b){
//        int c = a + b;
//        System.out.println(c);
//    }
//    public static void main(String[] args) {
//        number(100,7);
//    }
//}

//方法二:
public class Test1 {
    public static int hjm(int a, int b){
        return a + b;
    }
    public static void main(String[] args) {
        int num = hjm(100,7);
        System.out.println(num);
    }
}