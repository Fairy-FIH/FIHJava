import java.util.Scanner;

public class Test7 {
    public static void main(String[] args) {
        int[] arr = {1,432,5,45,765,876,65,32,12,43,65,77};
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入查询的数字");
        int a = sc.nextInt();
        System.out.println(cantains(arr,a));
    }
    public static boolean cantains(int[] arr,int a) {
        for (int i = 0;i < arr.length;i++){
            if(a == arr[i]){
                return true;
            }
        }
        return false;
    }
}