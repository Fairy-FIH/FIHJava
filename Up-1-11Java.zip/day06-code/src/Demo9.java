// 练习一：使用经典 for 循环
//请编写代码，遍历数组 scores = {85, 90, 78, 92}，找出并打印分数大于 90 的元素及其对应的索引

public class Demo9 {
    public static void main(String[] args) {
        int[] scores = {85, 90, 78, 92};
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > 90) {
                System.out.println("在第" + (i + 1) + "索引,该元素为" + scores[i]);
            }
        }
    }
}

//练习二：使用增强 for 循环
//请编写代码，遍历数组 prices = {10, 25, 5, 50}，计算并打印出所有元素值的总和。

//public class Demo9 {
//    public static void main(String[] args) {
//        int[] prices = {10, 25, 5, 50};
//        int sum = 0;
//        for(int num : prices){
//            sum += num;
//        }
//        System.out.println(sum);
//    }
//}