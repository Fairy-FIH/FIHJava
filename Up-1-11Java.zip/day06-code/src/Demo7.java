import java.util.Scanner;

public class Demo7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] number = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int i = 0; i < number.length; i++) {
            System.out.print(number[i] + " ");
        }
        System.out.println("请输入第一个要截取的值");
        int num1 = sc.nextInt();
        System.out.println("请输入第二个要截取的值");
        int num2 = sc.nextInt();

        int[] result = newLength(number, num1, num2);
        System.out.println("截取后的长度为");
        for (int i = 0; i < result.length; i++) {
            System.out.println(result[i]);
        }
        sc.close();
    }
    public static int[] newLength(int[] arr,int from,int to) {
        int newLength = to - from;
        int[] newarr = new int[newLength];
        for (int i = 0; i < newLength; i++) {
            newarr[i] = arr[from + i];
        }
        return newarr;
    }
}