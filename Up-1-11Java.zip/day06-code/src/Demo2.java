import java.util.Scanner;
public class Demo2 {
    static Scanner sc = new Scanner(System.in);
    public static int a(){
        System.out.println("输入a值");
        int a = sc.nextInt();
        return a;
    }
    public static int b(){
        System.out.println("输入b值");
        int b = sc.nextInt();
        return b;
    }
    public static boolean jy(int a,int b){
        if(a< 0 || b< 0 ){
            System.out.println("输入非法范围,结束");
            return false;
        }else {
            return true;
        }
    }
    public static int jf(int a,int b){
        return a + b;
    }
    public static int pf(int a,int b) {
        int pingfang = jf(a,b);
        return pingfang * pingfang;
    }
    public static void pr(){
        int aval = a();
        int bval = b();
        if(!jy(aval, bval)){
            sc.close();
            return;
        }
        System.out.println("加法结果为:" + jf(aval,bval));
        System.out.println("平方结果为:" + pf(aval,bval));
    }
    public static void main(String[] args) {
        pr();
    }
}