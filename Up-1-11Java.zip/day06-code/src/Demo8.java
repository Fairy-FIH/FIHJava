import java.util.Scanner;
import java.util.Arrays;

public class Demo8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int[] arr = {1,2,3,4,5,6,7,8,9};
        System.out.println(Arrays.toString(arr(arr,a,b)));
    }
    public static int[] arr(int[] arr,int a,int b) {
        int[] news = new int[b- a];
        int index = 0;
        for (int i = a; i < b; i++) {
            news[index] = arr[i];
            index++;
        }
        return news;
    }
}