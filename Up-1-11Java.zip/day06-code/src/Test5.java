public class Test5 {
        public static void main(String[] args) {
            int height = 5; // 设置三角形的高度

            // 打印正三角形
            printUpwardTriangle(height);

            System.out.println("\n----------------------\n");

            // 打印倒三角形
            printInvertedTriangle(height);
        }

        // 完整的正三角形方法
        public static void printUpwardTriangle(int height) {
            System.out.println("--- 打印高度为 " + height + " 的正三角形 ---");
            for (int i = 1; i <= height; i++) {
                // 打印空格
                for (int j = 1; j <= height - i; j++) {
                    System.out.print(" ");
                }
                // 打印星号
                for (int k = 1; k <= 2 * i - 1; k++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        }

        // 完整的倒三角形方法
        public static void printInvertedTriangle(int height) {
            System.out.println("--- 打印高度为 " + height + " 的倒三角形 ---");
            for (int i = height; i >= 1; i--) {
                // 打印空格
                for (int j = 1; j <= height - i; j++) {
                    System.out.print(" ");
                }
                // 打印星号
                for (int k = 1; k <= 2 * i - 1; k++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        }
}