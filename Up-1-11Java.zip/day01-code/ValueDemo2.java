public class ValueDemo2{
    public static void main(String[] args){
        System.out.println("我" + '\t' + "叫布吉岛");
    }
}