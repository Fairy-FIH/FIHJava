public class hello{
    // main方法,表示程序的主入口
    public void main(String[] args){
        /* 输出语句(打印语句)


         */
        System.out.println("你好");
    }
}