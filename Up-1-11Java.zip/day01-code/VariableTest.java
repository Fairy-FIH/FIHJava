public class VariableTest{
    public static void main(String[] Hjm){
        System.out.println("你好");
    }
}