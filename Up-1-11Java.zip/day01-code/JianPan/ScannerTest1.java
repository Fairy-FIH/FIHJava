import java.util.Scanner;

public class ScannerTest1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入a:");
        int a = sc.nextInt();


//        Scanner sb = new Scanner(System.in);
        System.out.println("请输入b:");
        int b = sc.nextInt();

        System.out.print(a + b);
    }
}