import java.util.Scanner;

public class ScannerDemo1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        String hjm = sc.nextLine();

        System.out.println(hjm);
    }
}