public class ValueDemo1{
    // main方法,表示程序的主入口
    public void main(String[] args){
        System.out.println("abc" + "\t" + "hjm");
        System.out.println(-999);

//        System.out.println(3.14159);
//        System.out.println(-3.14159);
//
//        System.out.println("黑马程序员");
//        System.out.println("郭嘉宇");
//
//        System.out.println('男');
//        System.out.println('女');
//
//        System.out.println(true);
//        System.out.println(false);
//
//        System.out.println("null");
    }
}