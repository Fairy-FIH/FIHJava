public class VariableDemo3 {
    public static void main(String[] args){
        // byte
        byte b = 127;
        // short
        short c = 32767;
        //int
        int d = 210000000;
        //long
        long e = 2147483648L;
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
        System.out.println(e);

        float p = 1.2345F;
        double O = 1.1234567;

        System.out.println(p);
        System.out.println(O);


        char H = '哈';
        System.out.println(H);


        boolean z = false;
        boolean x = true;
        System.out.println(z);
        System.out.println(x);

    }
}