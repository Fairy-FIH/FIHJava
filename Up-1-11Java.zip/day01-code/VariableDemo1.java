public class VariableDemo1{
    // 主入口
    public static void main(String[] args){
        // 数据类型 变量名 = 数据值;
        // int整数   double小数

        int a = 10;
        System.out.println(a);
        System.out.println(a);
        System.out.println(a);

        int b = 100;
        int c = 100;
        System.out.println(b + c);

        a = 50;
        System.out.println(a);

        System.out.println("-------------------------");

        int d = 50, e = 4, f = 5;
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
    }
}