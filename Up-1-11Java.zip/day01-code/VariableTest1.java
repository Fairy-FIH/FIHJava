public class VariableTest1 {
    public static void main(String[] args) {
        String name = "\"送初恋回家\"";
        String zhuyan = "刘鑫 张雨提 高媛";
        short nianfeng = 2020;
        double pingfeng = 9.0;
        boolean bochu = true;
        float piao = 19.9F;
        long ren = 12345678910L;

        System.out.println("\t" + name);
        System.out.println("主演是:" + zhuyan);
        System.out.println("上映年份-" + nianfeng);
        System.out.println("评分是:" + pingfeng);
        System.out.println("是否上映:" + bochu);
        System.out.println("票价:" + piao);
        System.out.println("观看人数是:" + ren);

        String pingpai1 = "华为";
        String pingpai2 = "荣耀";
        double jiage1 = 5299.00;
        double jiage2 = 1699.00;
        double jiage3 = 1499.00;

        System.out.println("手机品牌是:" + pingpai1 + "|" + "价格是:" + jiage1);
        System.out.println("手机品牌是:" + pingpai2 + "|" + "价格是:" + jiage2);
        System.out.println("手机品牌是:" + pingpai1 + "|" + "价格是:" + jiage3);

    }
}