import java.util.ArrayList;
import java.util.Scanner;

public class cunzai {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        ArrayList<user> list = new ArrayList<>();
        user u1 = new user(111,"小红","123456");
        user u2 = new user(222,"小白","321654");
        user u3 = new user(333,"小兰","098765");
        list.add(u1);
        list.add(u2);
        list.add(u3);
        System.out.println(fangwen(list));
        sc.close();
    }
    public static int fangwen(ArrayList<user> list) {
        System.out.print("请输入姓名:");
        String xingm = sc.nextLine();
        for (int i = 0; i < list.size(); i++) {
            if(list.get(i).getUsername().equals(xingm)) {
                list.get(i).xinxi();
                return i;
            }
        }
        return -1;
    }
}