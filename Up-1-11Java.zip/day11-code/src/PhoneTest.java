/*
定义Javabean类:Phone
Phone属性:品牌，价格。
main方法中定义一个集合，存入三个手机对象。分别为:小米 1000。苹果 8000。锤子 2999。
定义一个方法，将价格低于3000的手机信息返回。
 */

import java.util.ArrayList;

public class PhoneTest{
    public static void main(String[] args) {
        ArrayList<Phone> list = new ArrayList<>();
        Phone p1 = new Phone("小米",1000);
        Phone p2 = new Phone("苹果",8000);
        Phone p3 = new Phone("锤子",2999);
        list.add(p1);
        list.add(p2);
        list.add(p3);
        ArrayList<Phone> newlist = fanhui(list);
        for (Phone p : newlist){
            System.out.printf("品牌是:%s 价格是:%s\n",p.getPinpai(),p.getJiage());
        }
    }
    public static ArrayList<Phone> fanhui(ArrayList<Phone> list){
        ArrayList<Phone> fanhui = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getJiage() < 3000){
                fanhui.add(list.get(i));
            }
        }
        return fanhui;
    }
}