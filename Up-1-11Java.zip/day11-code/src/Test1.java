/*
集合的遍历方式
需求:定义一个集合，添加字符串，并进行遍历遍历格式参照:
[元素1,元素2,元素3]。
 */

import java.util.ArrayList;

public class Test1 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("小明");
        list.add("小花");
        list.add("小红");
        System.out.println(list);
        System.out.println(dayin(list));
    }
    public static String dayin(ArrayList<String> list) {
        StringBuilder zhong = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if(i == list.size() - 1){
                zhong.append(list.get(i));
            }else {
                zhong.append(list.get(i)).append(", ");
            }
        }
        return "[" + zhong.toString() + "]";
    }
}