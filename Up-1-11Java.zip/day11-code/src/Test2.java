/*
需求:定义一个集合，添加数字，并进行遍历。
遍历格式参照:[元素1,元素2,元素3]。
 */

import java.util.ArrayList;

public class Test2 {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        System.out.println(list);
        System.out.println(fanhui(list));
    }
    public static String fanhui(ArrayList<Integer> list){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            if(i == list.size() - 1){
                sb.append(list.get(i));
            }else {
                sb.append(list.get(i) + ", ");
            }
        }
        return "[" + sb.toString() + "]";
    }
}