import java.util.ArrayList;

public class AlTest1 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        // 增
        list.add("辽");
        list.add("宋");
        list.add("夏");
        list.add("金");
        list.add("元");
        list.add("明");
        boolean tj = list.add("清");
        System.out.println("添加:" + tj);
        // 删
        boolean shanchu = list.remove("金");
        System.out.println("删除:" + shanchu);
        /* list.remove(3); */
        // 查
        System.out.println("第5号位为:" + list.get(5));
        // 改
        list.set(5,"傻");


        System.out.println(list);
        for (int i = 0; i < list.size(); i++) {
            System.out.print(list.get(i) + " ");
        }
    }
}