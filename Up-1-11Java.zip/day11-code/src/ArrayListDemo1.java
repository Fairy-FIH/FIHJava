import java.util.ArrayList;

public class ArrayListDemo1 {
    public static void main(String[] args) {
//        ArrayListDemo2 people1 = new ArrayListDemo2("郭嘉文",11);
//        ArrayListDemo2 people2 = new ArrayListDemo2("郭嘉宇",18);
//        ArrayList<ArrayListDemo2> hjm = new ArrayList<>();
//        hjm.add(people1);
//        hjm.add(people2);
//        System.out.println(hjm.get(0).getName());
//        System.out.println(hjm.get(0).getAge());
        ArrayList<String> ddj = new ArrayList<>();
        boolean tj1 = ddj.add("郭嘉文是傻der");
        boolean tj2 = ddj.add("郭嘉文今天作业没写完");
        System.out.println("添加1:" + tj1);
        System.out.println("添加2:" + tj2);
//        boolean sc1 = ddj.remove("郭嘉文今天作业没写完");
//        System.out.println("删除郭嘉文没写作业:" + sc1);
//        String gai1 = ddj.set(0,"郭嘉文最聪明了");
//        System.out.println(gai1);
        ddj.set(0,"郭嘉文最聪明了");
        System.out.println(ddj.size());
        System.out.println("所有元素:" + ddj);
    }
}