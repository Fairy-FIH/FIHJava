import java.util.ArrayList;
import java.util.Scanner;

public class Test3 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        ArrayList<Student> list = new ArrayList<>();
        for(int i = 1;i < 3;i++){
            Student stu = new Student();
            System.out.print("请输入对象" + i + "姓名:");
            stu.setName(sc.next());
            System.out.print("请输入对象" + i + "年龄:");
            stu.setAge(sc.nextInt());
            list.add(stu);
        }
        System.out.println(bianli(list));
    }
    public static String bianli(ArrayList<Student> list){
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(int i = 0;i < list.size();i++){
            if (i == list.size()-1){
                sb.append(list.get(i).getName()).append(", ").append(list.get(i).getAge());
            }else {
                sb.append(list.get(i).getName()).append(", ").append(list.get(i).getAge()).append("; ");
            }
        }
        return sb.append("]").toString();
    }
}