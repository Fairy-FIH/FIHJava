public class Teacherff {
    public static void main(String[] args) {
        String us1 = "abcde";
        String us2 = "cdeab";
        System.out.println(pd(us1, us2));
    }
    public static String chongzu(String us){
        char dyw = us.charAt(0);
        String hou = us.substring(1);
        return hou + dyw;
    }
    public static boolean pd(String us,String pdz){
        for (int i = 0; i < pdz.length(); i++){
            us = chongzu(us);
            if (us.equals(pdz)){
                return true;
            }
        }
        return false;
    }
}