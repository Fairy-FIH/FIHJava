public class shenfenzheng {
    private String shenfenzheng;

    public shenfenzheng(){};
    public shenfenzheng(String shenfenzheng){
        this.shenfenzheng = shenfenzheng;
    }
    public void setShenfenzheng(String shenfenzheng){
        this.shenfenzheng = shenfenzheng;
    }
    public String getShenfenzheng(){
        return shenfenzheng;
    }
}