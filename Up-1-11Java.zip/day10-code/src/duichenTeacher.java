import java.util.Scanner;

public class duichenTeacher {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.print("输入字符串:");
        String str = sc.nextLine();

        // 链式简写版
        String result = new StringBuilder().append(str).reverse().toString();
        if (str.equals(result)) {
            System.out.println("该字符串是对称字符串");
        }else {
            System.out.println("该字符串是非对称字符串");
        }

        System.out.println();

        // 链式三元运算超级简写版
        String print = new StringBuilder().append(str).reverse().toString().equals(str)?"是对称字符串":"是非对称字符串";
        System.out.println(print);
    }
}

/*
需求:键盘接受一个字符串，程序判断出该字符串是否是对称字符串
并在控制台打印是或不是对称字符串:123321、111
非对称字符串:123123
 */