/*需求:键盘录入一个字符串，使用程序实现在控制台遍历该字符串*/

import java.util.Scanner;

public class Demo3 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        String[] yuanshi = new String[10];
        int count = 0;
        System.out.println("请输入字符");
        yuanshi[count] = sc.nextLine();
        count++;
        while(true){
            if(jixu()){
                System.out.println("请输入字符");
                yuanshi[count] = sc.nextLine();
                count++;
            }else {
                break;
            }
        }
        String[] newarr = arr(count);
        for (int i = 0; i < yuanshi.length; i++) {
            if (yuanshi[i] != null){
                newarr[i] = yuanshi[i];
            }
        }
        System.out.println("新数组");
        for (String s : newarr) {
            System.out.println(s);
        }
    }
    public static String[] arr(int count){
        return new String[count];
    }
    public static boolean jixu(){
        System.out.println("是否继续录入数据 1,录入  2,暂停录入");
        String luru = sc.nextLine();
        if(luru.equals("1")){
            return true;
        }
        return false;
    }
}