/* 需求:已知正确的用户名和密码，请用程序实现模拟用户登录。
总共给三次机会，登录之后，给出相应的提示
 */
import java.util.Scanner;

public class Demo2 {
    private static String name = "gjy";
    private static String mima = "gjy123";
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int count = 0;
        boolean flag = false;
        for (int i = 1; i < 4; i++) {
            if(count == 3){
                break;
            }
            System.out.println("===请输入账号====");
            String userinput = sc.nextLine();
            if(userinput.equals(name)){
                System.out.println("账号正确");
                System.out.println("账号成功后密码有三次机会.注意!一旦密码三次也失败即退出服务");
                for(int j = 1; j < 4; j++){
                    System.out.println("===请输入密码===");
                    String usermima = sc.nextLine();
                    if(usermima.equalsIgnoreCase(mima)){
                        flag = true;
                        System.out.println("密码正确!");
                        break;
                    }else {
                        count++;
                        System.out.println("\u001B[31m密码错误!\u001B[0m " + ((3 - j) == 0?" ":"还剩"  +(3 - j) + "次机会"));
                    }
                }
                if(flag){
                    break;
                }
            }else {
                System.out.println("账号错误! " + ((3 - i) == 0?" ":"还剩"  +(3 - i) + "次机会"));
            }
        }
        if(flag){
            System.out.println("登录成功!");
        }else {
            System.out.println("登录失败!");
        }
    }
}