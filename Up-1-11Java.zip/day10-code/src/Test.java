/*
统计字符次数
键盘录入一个字符串，统计该字符串中大写字母字符，小写字母字符，数字字符出现的次数(不考虑其他字符)
*/

import java.util.Scanner;

public class Test {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.print("请输入字符串:");
        String input = sc.nextLine();
        int daxie = 0;
        int xiaoxie = 0;
        int shuzi = 0;
        for(int i = 0;i < input.length();i++){
//            if(input.charAt(i) <= 90 && input.charAt(i) >= 65){
//                daxie++;
//            }
//            else if (input.charAt(i) <= 122 && input.charAt(i) >= 97) {
//                xiaoxie++;
//            }
//            else{
//                shuzi++;
//            }
            if(input.charAt(i) <= 'Z' && input.charAt(i) >= 'A'){
                daxie++;
            }
            else if (input.charAt(i) <= 'z' && input.charAt(i) >= 'a') {
                xiaoxie++;
            }
            else{
                shuzi++;
            }
        }
        System.out.println("大写有:" + daxie);
        System.out.println("小写有:" + xiaoxie);
        System.out.println("数字有:" + shuzi);
    }
}