/*
给定两个字符串,A和B.
A的旋转操作就是将 A最左边的字符移动到最右边。
例如,若 A='abcde'，在移动一次之后结果就是'bcdea'
如果在若干次调整操作之后，A能变成B，那么返回True。
如果不能匹配成功，则返回false
 */

public class shuangzhizhen {
    public static void main(String[] args) {
        StringBuilder A = new StringBuilder("abcde");
        // 原字符串
        StringBuilder B = new StringBuilder("abcxz");
        // 匹配字符串
        boolean flag = pd(A,B);
        // 接收返回值
        System.out.println(flag);
    }
    public static boolean pd(StringBuilder A, StringBuilder B) {
        // 获取原始字符串
        int length = A.length();
        // 将原始字符串+原始字符串!!!如果A可以旋转成B那么B一定在A+A的结果里面
        StringBuilder C = new StringBuilder(A.append(A));
        // 开始循环,直到小于匹配字符串长度
        for (int i = 0; i < B.length(); i++) {
            // 定义新字符串,其每次截获长度为:(i到i+原始字符串)
            StringBuilder D = new StringBuilder(C.substring(i,length + i));
            // 输出截获长度内的值
            System.out.println(D.toString());
            // 进行判断是否字符串匹配
            if (D.toString().equalsIgnoreCase(B.toString())) {
                // 一旦匹配成功,立即返回true
                return true;
            }
        }
        // 循环结束,匹配字符串对不上撤出,返回flase
        return false;
    }
}