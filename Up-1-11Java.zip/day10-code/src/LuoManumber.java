import java.util.Scanner;
import java.util.StringJoiner;
public class LuoManumber {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        String[] arr = {"","I","II","III","IV","V","VI","VII","VIII","IX"};
        System.out.print("注意:该程序只做数字转换!请输入数字:");
        String userInput = sc.nextLine();
        if (yanzhen(userInput)) {
            System.out.println(fanhui(userInput,arr));
        }else {
            System.out.println("该程序只做数字转换,且长度不得超过9!");
        }
        sc.close();
    }
    public static boolean yanzhen(String userInput) {
        if(userInput.length() > 9){
            return false;
        }
        for (int i = 0; i < userInput.length(); i++) {
            if ((userInput.charAt(i) < '0' || userInput.charAt(i) > '9')) {
                return false;
            }
        }
        return true;
    }
    public static String fanhui(String user,String[] arr){
        StringJoiner sj = new StringJoiner(",","[","]");
        for(int i=0;i<user.length();i++){
            int num = user.charAt(i) - '0';
            sj.add(arr[num]);
        }

        return sj.toString();
    }
}