public class pingjieString {
    public static void main(String[] args) {
        int[] arr = new int[]{1,2,3,4,5,6,7,8,9};
        System.out.println(ff(arr));
    }
    public static String ff(int[] arr){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            if (i == arr.length - 1) {sb.append(arr[i]);}
            else {sb.append(arr[i]).append(",");}
        }
        return "[" + sb + "]";
    }
}