/*给定两个以字符串形式表示的非负整数num1和num2，
返回num1和num2的乘积，
它们的乘积也表示为字符串形式
注意:需要用己有的知识完成。*/

public class Testlx4 {
    public static void main(String[] args) {
        String yi = "150000000000000000";
        String er = "8";
        System.out.println("结果为:" + fanhui(yi,er));
    }
    public static String fanhui(String yi,String er){
        char[] a1 = yi.toCharArray();
        char[] b1 = er.toCharArray();
        long a2 = 0;
        for (int i = 0; i < a1.length; i++) {
            a2 = (a2 * 10) + (a1[i] - '0');
        }
        long b2 = 0;
        for (int i = 0; i < b1.length; i++) {
            b2 = (b2 * 10) + (b1[i] - '0');
        }
        long zz = a2 * b2;
        System.out.println(zz);
        return zz + "";
    }
}