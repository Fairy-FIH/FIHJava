/*
键盘输入任意字符串，打乱里面的内容
 */

import java.util.Scanner;
import java.util.Random;

public class Daluan {
    static Scanner sc = new Scanner(System.in);
    static Random rand = new Random();
    public static void main(String[] args) {
        String zfc = sc.nextLine();
        System.out.println(daluan(zfc));
    }
    public static String daluan(String zfc){
        //定义一个方法,用来返回打乱后的字符串
        char[] ch = zfc.toCharArray();
        // 将拿到的字符串转成char数组
        for(int i = zfc.length() - 1; i > 0; i--){
            // 费耶洗牌算法,从后往前洗,洗到没值为止
            int j = rand.nextInt(0,i + 1);
            // 定义一个随机索引位,随机范围每次在0~i+1之间
            // 交换位置
            char temp = ch[j];
            ch[j] = ch[i];
            ch[i] = temp;
        }
        // 返回字符串
        return new String(ch);
    }
}