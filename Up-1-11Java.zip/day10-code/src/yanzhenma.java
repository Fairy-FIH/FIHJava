/*内容:可以是小写字母，也可以是大写字母，还可以是数字规则:
长度为5
内容中是四位字母，1位数字。
其中数字只有1位，但是可以出现在任意的位置。*/

import java.util.Random;

public class yanzhenma {
    static Random rand = new Random();
    static char[] fanw = {
            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
            'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    };
    public static void main(String[] args) {
        char[] arr = new char[5];
        for (int i = 0; i < arr.length; i++) {
            int r = rand.nextInt(fanw.length);
            arr[i] = fanw[r];
        }
        int sj = rand.nextInt(arr.length);
        arr[sj] = (char) rand.nextInt('1','9' + 1);
        String s = new String(arr);
        System.out.println(s);
    }
}