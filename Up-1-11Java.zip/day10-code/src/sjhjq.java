import java.util.Scanner;

public class sjhjq {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.print("请输入手机号:");
        String sjh = sc.nextLine();
        String newsjh = sjh.substring(3,7);
        String qian = sjh.substring(0,3);
        String hou = sjh.substring(7,11);
        String newsjh2 = "";
        for (int i = 0; i < newsjh.length(); i++) {
            newsjh2 += "*";
        }
        String end = qian + newsjh2 + hou;
        System.out.println(end);
    }
}