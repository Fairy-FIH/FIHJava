import java.util.Random;

public class yinhangkascq {
    public static void main(String[] args) {
        Random rand = new Random();
        String end = "";
        for (int i = 0; i < 16; i++) {
            int yhk = rand.nextInt(10);
            end += yhk;
        }
        System.out.println("随机生成的银行卡号为:" + end);
    }
}


/*
背景： 由于隐私保护，银行后台系统在显示用户的 16 位银行卡号时，不能直接显示中间的数字。

要求：
输入：从键盘录入一个 16位 的银行卡号字符串（假设全部是数字，暂不考虑非数字校验）。
处理：
保留前 4 位。
保留后 4 位。
中间的 8 位数字，请先全部替换成字符 *。
(重点!)在输出时，要求每 4 位后面加一个空格，变成 XXXX **** **** XXXX 的格式。

输出：打印脱敏并格式化后的结果。
 */