import java.util.Scanner;
public class LuomashuziSwitch {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.print("请输入数字:");
        String userInput = sc.nextLine();
        if (yanzhen(userInput)) {
            System.out.println(fanh(userInput));
        } else {
            System.out.println("该程序只做数字转换,且长度不得超过9!");
        }
    }
    public static boolean yanzhen(String userInput) {
        if (userInput.length() > 9) {
            return false;
        }
        for (int i = 0; i < userInput.length(); i++) {
            if ((userInput.charAt(i) < '0' || userInput.charAt(i) > '9')) {
                return false;
            }
        }
        return true;
    }
    public static String fanh(String user) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < user.length(); i++) {
            char ch = user.charAt(i);
            switch (ch) {
                case '1' -> sb.append("I");
                case '2' -> sb.append("II");
                case '3' -> sb.append("III");
                case '4' -> sb.append("IV");
                case '5' -> sb.append("V");
                case '6' -> sb.append("VI");
                case '7' -> sb.append("VII");
                case '8' -> sb.append("VIII");
                case '9' -> sb.append("IX");
                default -> sb.append("");
            };
        }
        return sb.toString();
    }
}