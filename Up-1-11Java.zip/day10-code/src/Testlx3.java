/*
键盘输入任意字符串，打乱里面的内容
 */

import java.util.Scanner;
import java.util.Random;

public class Testlx3 {
    static Scanner sc = new Scanner(System.in);
    static Random rand = new Random();
    public static void main(String[] args) {
        System.out.print("请输入字符:");
        String input = sc.nextLine();
        System.out.print("打乱后:" + daluan(input));
    }
    public static String daluan(String input){
        char[] ch = input.toCharArray();
        for(int i = ch.length - 1;i > 0;i--){
            int sj = rand.nextInt(i + 1);
            char temp = ch[i];
            ch[i] = ch[sj];
            ch[sj] = temp;
        }
        return new String(ch);
    }
}