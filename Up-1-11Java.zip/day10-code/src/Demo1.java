import java.math.BigDecimal;
import java.util.Scanner;

public class Demo1 {
    public static void main(String[] args) {
//        String a = "hda321312";
//        String b = "Hda321312";
//        String c = new String("Hello");
//        if(a.equalsIgnoreCase(b)){
//            System.out.println("正确的!匹配上了");
//        }else {
//            System.out.println("错误的,没匹配上");
//        }
//        System.out.println();
//        char[] q = {'a', 'b', 'c'};
//        String w = new String(q);
//        System.out.println(w);
//        System.out.println();
//        byte[] zj = {97,98,99,100};
//        String pj1 = new String(zj);
//        System.out.println(pj1);
//
        Scanner sc = new Scanner(System.in);
        String str = "你好";
        String str2 = sc.nextLine();
        if(str == str2) {
            System.out.println("地址一样");
        }else {
            System.out.println("地址不一样");
        }
    }
}