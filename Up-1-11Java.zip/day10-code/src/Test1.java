/* 定义一个方法
把int数组中的数据按照指定的格式拼接成一个字符串返回
调用该方法，并在控制台输出结果。
例如:
数组为 int[] arr = {1,2,3};
执行方法后的输出结果为:[1,2,3]
第二步
反转该数据
 */


import java.util.Arrays;

public class Test1 {
    public static void main(String[] args) {
        int[] arr = new int[]{1,2,3};
        String pinjie = pinjie(arr);
        System.out.println(pinjie);
        System.out.println("方法1反转后:");
        String fanzhuan1 = fanzhuan(pinjie);
        System.out.println(fanzhuan1);
        System.out.println("方法2反转后:");
        String fanzhuan2 = fanzhuan1(pinjie);
        System.out.println(fanzhuan2);
    }
    public static String pinjie(int[] arr){
        String newarr = "";
        for(int i=0; i<arr.length; i++){
            if(i == arr.length-1){
                newarr += arr[i];
            }else {
                newarr += arr[i] + ", ";
            }
        }
        return "[" + newarr + "]";
    }
    public static String fanzhuan(String zfc){
        String newzfc = "";
        for(int i = zfc.length() - 1; i >= 0; i--){
            if(zfc.charAt(i) <= '9' && zfc.charAt(i) >= '0'){
                newzfc += zfc.charAt(i);
            }
        }
        String fanzhuan = "";
        for(int i = 0;i < newzfc.length();i++){
            if (i == newzfc.length() - 1){
                fanzhuan += newzfc.charAt(i)+"";
            }else {
                fanzhuan += newzfc.charAt(i)+", ";
            }
        }
        return "[" +  fanzhuan + "]";
    }
    public static String fanzhuan1(String zfc){
        int count = 0;
        char[] fanzhuan = new char[zfc.length()];
        for (int i = 0; i < zfc.length(); i++) {
            if (zfc.charAt(i) <= '9' && zfc.charAt(i) >= '0') {
                fanzhuan[i] = zfc.charAt(i);
                count++;
            }
        }
        char[] xinchar = new char[count];
        for(int i = 0,j = 0;i < fanzhuan.length;i++){
            if(fanzhuan[i] <= '9' && fanzhuan[i] >= '0'){
                xinchar[j] = fanzhuan[i];
                j++;
            }
        }
        for (int i = 0,j = xinchar.length - 1;i<j;i++,j--){
            char temp = xinchar[i];
            xinchar[i] = xinchar[j];
            xinchar[j] = temp;
        }
        String fanzhuan2 = "";
        for(int i = 0;i < xinchar.length;i++){
            if(i == xinchar.length - 1){
                fanzhuan2 += xinchar[i]+"";
            }else {
                fanzhuan2 += xinchar[i]+", ";
            }
        }
        return "[" + fanzhuan2 + "]";
    }
}