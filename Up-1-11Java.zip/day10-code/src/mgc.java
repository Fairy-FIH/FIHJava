public class mgc {
    public static void main(String[] args) {
        String[] ciku = {"TMD","NTMD","傻逼","煞笔","屋里那两位不要了吗","孙子","儿子","死全家"};
        String xiaoming = "你TMD是煞笔吧,屋里那两位不要了吗,等着死全家吧!孙子";
        for (int i = 0; i < ciku.length; i++) {
            xiaoming = xiaoming.replace(ciku[i], "***");
        }
        System.out.println(xiaoming);
    }
}