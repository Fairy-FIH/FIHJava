import java.util.Scanner;

public class Phonenum {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        String phonenum;
        boolean flag = false;
        while(true){
            System.out.print("输入手机号:");
            phonenum = sc.nextLine();
            for(int i = 0; i < phonenum.length(); i++){
                if((phonenum.charAt(i) >= '0' && phonenum.charAt(i) <= '9') && phonenum.length() == 11){
                    flag = true;
                }else {
                    System.out.println("请输入正确的手机号码!");
                    flag = false;
                    break;
                }
            }
            if(flag){
                break;
            }
        }
        if (flag){
            char[] phone = new char[phonenum.length()];
            for (int i = 0; i < phone.length; i++) {
                phone[i] = phonenum.charAt(i);
            }
            for (int j = 3; j < 7; j++) {
                phone[j] = '*';
            }
            for (char c : phone) {
                System.out.print(c);
            }
        }
    }
}