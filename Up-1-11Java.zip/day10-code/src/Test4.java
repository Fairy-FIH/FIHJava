import java.util.Scanner;

public class Test4 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        String[] table = new String[]{"零","壹","贰","叁","肆","伍","陆","柒","捌","玖"};
        String[] danwei = new String[]{"元", "拾", "佰", "仟", "万", "拾", "佰", "仟"};
        String[] end = new String[danwei.length];
        System.out.println("请输入数字");
        String user = sc.nextLine();
        String pass = "";
        for (int i = 0; i < user.length(); i++) {
            int num = user.charAt(i) - '0';
            pass += table[num];
        }
        int height = user.length();
        String[] temp = new String[height];
        for (int i = 0; i < height; i++) {
            temp[i] = danwei[i];
        }
        int index = danwei.length - height;
        for(int i = 0,j = temp.length - 1;i < user.length();i++,j--){
            end[index + i] = (pass.charAt(i) + danwei[j]);
        }
        for (int i = 0; i < index; i++) {
            int unitIndex = danwei.length - 1 - i;
            end[i] = "零" + danwei[unitIndex];
        }
        for (int i = 0; i < end.length; i++) {
            System.out.print(end[i]);
        }
    }
}





//            if(user.charAt(i) == '1'){
//                pass += table[1];
//            }else if(user.charAt(i) == '2'){
//                pass += table[2];
//            }else if(user.charAt(i) == '3'){
//                pass += table[3];
//            }else if(user.charAt(i) == '4'){
//                pass += table[4];
//            }else if(user.charAt(i) == '5'){
//                pass += table[5];
//            }else if(user.charAt(i) == '6'){
//                pass += "陆";
//            }else if(user.charAt(i) == '7'){
//                pass += "柒";
//            }else if(user.charAt(i) == '8'){
//                pass += "捌";
//            }else if(user.charAt(i) == '9'){
//                pass += "玖";
//            }