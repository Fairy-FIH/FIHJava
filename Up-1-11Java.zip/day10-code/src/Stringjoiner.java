import java.util.StringJoiner;

public class Stringjoiner {
    public static void main(String[] args) throws Exception {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        StringJoiner sj = new StringJoiner("-","[","]");
        for (int i = 0; i < arr.length; i++) {
            sj.add(arr[i] + "");
        }
        System.out.println(sj);
        StringJoiner sj2 = new StringJoiner(",","]","[");
        for(int i : arr) {
            sj2.add(i + "");
        }
        StringBuilder sb = new StringBuilder(sj2.toString());
        System.out.println(sb.reverse());
    }
}