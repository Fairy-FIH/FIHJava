/*内容:可以是小写字母，也可以是大写字母，还可以是数字规则:
长度为5
内容中是四位字母，1位数字。
其中数字只有1位，但是可以出现在任意的位置。*/

import java.util.Random;

public class Testlx2 {
    static Random rand = new Random();
    static char[] zf = {
            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
            'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    };
    public static void main(String[] args) {
        System.out.println("生成验证码中");
        System.out.println(yzm());

    }
    public static String yzm(){
        char[] yzm = new char[5];
        for(int i = 0;i < yzm.length;i++){
            int r = rand.nextInt(zf.length);
            yzm[i] = zf[r];
        }
        int num = rand.nextInt(yzm.length);
        char shuzi = (char)('0' + rand.nextInt(10));
        yzm[num] = shuzi;
        return new String(yzm);
    }
}