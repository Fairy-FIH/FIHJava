/*给定两个以字符串形式表示的非负整数num1和num2，
返回num1和num2的乘积，
它们的乘积也表示为字符串形式
注意:需要用己有的知识完成。*/

// 该方法不对!已失效

import java.util.Arrays;

public class newTest {
    public static void main(String[] args) {
        String num1 = "132";
        String num2 = "10";
        System.out.println("最终结果:" + zuiz(num1, num2));
    }
    public static int zuiz(String num1,String num2){
        int[] dw = {1,10,100,1000,10000,100000};
        int[] number1 = new int[num1.length()];
        int[] number2 = new int[num2.length()];
        int a = 0;
        for (int i = 0; i < num1.length(); i++) {
            if (i > 0){
                number1[i] = ((num1.charAt(i) - '0') == 0 ? 1:(num1.charAt(i) - '0')) * dw[a];
            }else {
                number1[i] = num1.charAt(i) - '0';
            }
            a++;
        }
        int num1Sum = 0;
        for (int i = 0; i < number1.length; i++) {
            if (!(number1[i] == 0)){
                num1Sum += number1[i];
            }
        }
        System.out.println(Arrays.toString(number1));
        System.out.println(num1Sum);


        int b = 0;
        for (int i = 0; i < num2.length(); i++) {
            if (i > 0){
                number2[i] = ((num2.charAt(i) - '0') == 0 ? 1:(num2.charAt(i) - '0')) * dw[b];
            }else {
                number2[i] = num2.charAt(i) - '0';
            }
            b++;
        }
        int num2Sum = 0;
        for (int i = 0; i < num2.length(); i++) {
            num2Sum += number2[i];
        }
        System.out.println(Arrays.toString(number2));
        System.out.println(num2Sum);



        int z = num1Sum * num2Sum;

        return z;
    }
}