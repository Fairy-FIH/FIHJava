public class pbc {
    public static void main(String[] args) {
        String a1 = "就说你了,你煞笔吧";
        String a2 = a1.substring(6,8);
        System.out.println(a1);
        System.out.println(a2);
        System.out.println();
        String print = hjm(a1,6,8,"煞笔","好人");
        System.out.println(print);
    }
    public static String hjm(String a1,int qianm,int zj,String smz,String gsm) {
        String qian = a1.substring(0,qianm);
        String sahnchu = a1.substring(qianm,zj);
        String gaizi = sahnchu.replace(smz,gsm);
        String hou = a1.substring(zj);
        return qian + gaizi + hou;
    }
}