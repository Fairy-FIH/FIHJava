/*给你一个字符串 s，由若干单词组成，单词前后用一些空格字符隔开。
返回字符串中最后一个单词的长度。
单词是指仅由字母组成、不包含任何空格字符的最大子字符串。

示例 1:输入:s="Hello World“输出:5
解释:最后一个单词是“World”，长度为5。

示例 2:输入:s="   fly me   to   the moon"输出:4
解释:最后一个单词是“moon”，长度为4。

示例 3:输入:s="luffy is still joyboy"输出:6
解释:最后一个单词是长度为6的“joyboy”
 */

import java.util.Arrays;

public class NewDemo1 {
    static char[] fanw = {
            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
            'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    };
    public static void main(String[] args) {
        String str = "luffy is still joyboy";
        System.out.println("长度为:" + cd(str));
    }
    public static int cd(String str){
        char[] ch = str.toCharArray();
        for(int i=0;i<ch.length;i++){
            boolean flag = false;
            for(int j=0;j<fanw.length;j++){
                if(ch[i]==fanw[j]){
                    flag = true;
                    break;
                }
            }
            if(!flag){
                ch[i] = '!';
            }
            System.out.print(ch[i]);
        }
        System.out.println();
//        int num = 0;
//        for(int i=ch.length - 1;i> 0;i--){
//            if(ch[i]=='!' && ch[i-1]=='!'){
//                num += 2;
//            }else if(ch[i] == '!'){
//                num += 1;
//            }
//        }
        int count = 0;
        for(int j = str.length() - 1;j > 0;j--){
            boolean pd = false;
            for (int i = 0; i < fanw.length; i++) {
                if (str.charAt(j) == fanw[i]) {
                    pd = false;
                    break;
                }else {
                    pd = true;
                }
            }
            if(pd){
                break;
            }else {
                count++;
            }
        }
        return count;
    }
}