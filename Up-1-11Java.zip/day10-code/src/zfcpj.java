import java.util.Scanner;

public class zfcpj {
    public static void main(String[] args) {
        String s= getstring();
        System.out.println("长度"+s.length() +"第0个字符"+ s.charAt(0) +"截取3以后的"+ s.substring(3) +"将a替换"+ s.replace("a","你好"));

    }
    public static String getstring(){
        Scanner sc= new Scanner(System.in);
        System.out.println("请输入一个字符串");
        String str = sc.next();
        return str;
    }
}