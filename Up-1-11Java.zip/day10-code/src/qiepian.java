/*
给定两个字符串,A和B.
A的旋转操作就是将 A最左边的字符移动到最右边。
例如,若 A='abcde'，在移动一次之后结果就是'bcdea'
如果在若干次调整操作之后，A能变成B，那么返回True。
如果不能匹配成功，则返回false
 */

public class qiepian {
    public static void main(String[] args) {
        StringBuilder A = new StringBuilder("abcde");
        StringBuilder B = new StringBuilder("eabcd");
        boolean flag = pd(A,B);
        System.out.println(flag);
    }
    public static boolean pd(StringBuilder A, StringBuilder B) {
        for (int i = 0; i < A.length(); i++) {
            StringBuilder bj = new StringBuilder();
            bj.append(A.substring(i + 1)).append(A.substring(0,i + 1));
            System.out.println(bj.toString());
            if (bj.toString().equals(B.toString())) {
                return true;
            }
        }
        return false;
    }
}