public class zfcarray {
    public static void main(String[] args) {
        String A = "abcde";
        String B = "eabcd";
        System.out.println(pd(A,B));
    }
    public static String zhuanhuan(String n) {
        char[] ch = n.toCharArray();
        char yihaowei = ch[0];
        for (int i = 1; i < ch.length; i++) {
            ch[i - 1] = ch[i];
        }
        ch[ch.length - 1] = yihaowei;
        return new String(ch);
    }
    public static boolean pd(String A,String B){
        for (int i = 0; i < A.length(); i++) {
            A = zhuanhuan(A);
            if(A.equals(B)){
                return true;
            }
        }
        return false;
    }
}