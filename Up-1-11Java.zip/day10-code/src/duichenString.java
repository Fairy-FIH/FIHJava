/*
需求:键盘接受一个字符串，程序判断出该字符串是否是对称字符串
并在控制台打印是或不是对称字符串:123321、111
非对称字符串:123123
 */

import java.util.Scanner;

public class duichenString {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        StringBuilder user = userinput();
        boolean flag = panduan(user);
        if (flag) {
            System.out.println("该字符串是对称字符串");
        }else {
            System.out.println("该字符串是非对称字符串");
        }
    }
    public static StringBuilder userinput(){
        System.out.print("请输入一个字符串:");
        StringBuilder user = new StringBuilder(sc.nextLine());
        return user;
    }
    // 反转校验
//    public static boolean panduan(StringBuilder input){
//        for (int i = 0,j = input.length() - 1; i < j; i++,j--) {
//            if(input.charAt(i) != input.charAt(j)){
//                return false;
//            }
//        }
//        return true;
//    }
    // 双指针校验
    public static boolean panduan(StringBuilder input){
        StringBuilder input1 = new StringBuilder(input.toString());
        input1.reverse();
        for (int i = 0; i < input1.length(); i++) {
            if (input.charAt(i) != input1.charAt(i)) {
                return false;
            }
        }
        return true;
    }
}