/* 该方法已遗弃 */

import java.util.Scanner;

public class Test2 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        char[] luru = zhuanhuan();
        for (int i = 0; i < luru.length; i++) {
            if (luru[i] < '0' || luru[i] > '9') {
                System.out.println("录入失败!");
                return;
            }
        }
        char[] zw = zhongwen(luru);
        String[] zz = zhongwenshuzi(zw);
        for (int i = 0; i < zz.length; i++) {
            if (zz[i].charAt(i) == '零') {
                zz[i] = "一";
            }else {
                System.out.print(zz[i]);
            }
        }
    }

    public static char[] zhuanhuan() {
        System.out.print("请输入金额:");
        String jine = sc.nextLine();
        char[] cd = new char[jine.length()];
        for (int i = 0; i < jine.length(); i++) {
            if (jine.charAt(i) < '0' || jine.charAt(i) > '9') {
                break;
            }else {
                cd[i] = jine.charAt(i);
            }
        }
        return cd;
    }

    public static String[] zhongwenshuzi(char[] zhongwen) {
        String[] xinshuzi = new String[zhongwen.length];
        String[] danwei = {"元", "拾", "佰", "仟", "万", "拾", "佰", "仟", "亿"};

//        xinshuzi[0] = zhongwen[zhongwen.length - 1] + "元";
//        xinshuzi[1] = zhongwen[zhongwen.length - 2] + "拾";
//        xinshuzi[2] = zhongwen[zhongwen.length - 3] + "佰";
//        xinshuzi[3] = zhongwen[zhongwen.length - 4] + "仟";
//        xinshuzi[4] = zhongwen[zhongwen.length - 5] + "万";
//        xinshuzi[5] = zhongwen[zhongwen.length - 6] + "拾";
//        xinshuzi[6] = zhongwen[zhongwen.length - 7] + "佰";
//        xinshuzi[7] = zhongwen[zhongwen.length - 8] + "仟";
//        xinshuzi[8] = zhongwen[zhongwen.length - 9] + "亿";

        for (int i = 0; i < zhongwen.length; i++) {
            char num = zhongwen[zhongwen.length - 1 - i];
            xinshuzi[i] = num + danwei[i];
        }

//        int min = 0;
//        int max = zhongwen.length - 1;
//        while (min < max) {
//            if (zhongwen[max] == '零') {
//                xinshuzi[0] = zhongwen[max - 1] + "元";
//                max--;
//                min++;
//            }
//            xinshuzi[min] = zhongwen[max] + "拾";
//            max--;
//            min++;
//            xinshuzi[min] = zhongwen[max] + "佰";
//            max--;
//            min++;
//            xinshuzi[min] = zhongwen[max] + "仟";
//            max--;
//            min++;
//            xinshuzi[min] = zhongwen[max] + "万";
//            max--;
//            min++;
//            xinshuzi[min] = zhongwen[max] + "拾";
//            max--;
//            min++;
//            xinshuzi[min] = zhongwen[max] + "佰";
//            max--;
//            min++;
//            xinshuzi[min] = zhongwen[max] + "仟";
//            max--;
//            min++;
//            xinshuzi[min] = zhongwen[max] + "亿";
//            max--;
//            min++;
//        }

        for (int i = 0,j = xinshuzi.length - 1; i < j; i++,j--) {
            String temp = xinshuzi[i];
            xinshuzi[i] = xinshuzi[j];
            xinshuzi[j] = temp;
            if (xinshuzi[i] == null) {
                xinshuzi[i] = "0";
            }
        }

        return xinshuzi;
    }
    
    public static char[] zhongwen(char[] zhuanhuan) {
        char[] Chinese = new char[zhuanhuan.length];
        for (int i = 0; i < zhuanhuan.length; i++) {
            if (zhuanhuan[i] == '1') {
                Chinese[i] = '壹';
            }else if (zhuanhuan[i] == '2') {
                Chinese[i] = '贰';
            }else if (zhuanhuan[i] == '3') {
                Chinese[i] = '叁';
            }else if (zhuanhuan[i] == '4') {
                Chinese[i] = '肆';
            }else if (zhuanhuan[i] == '5') {
                Chinese[i] = '伍';
            }else if (zhuanhuan[i] == '6') {
                Chinese[i] = '陆';
            }else if (zhuanhuan[i] == '7') {
                Chinese[i] = '柒';
            }else if (zhuanhuan[i] == '8') {
                Chinese[i] = '捌';
            }else if (zhuanhuan[i] == '9') {
                Chinese[i] = '玖';
            }else if (zhuanhuan[i] == '0') {
                Chinese[i] = '零';
            }
        }
        return Chinese;
    }

}