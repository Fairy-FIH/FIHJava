import java.util.Scanner;

public class test112 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        String kahao = kaHao();
        System.out.printf("原银行卡号为:%s\n",kahao);
        String end = shuCu(kahao);
        System.out.printf("脱敏后卡号为:%s\n",end);
        String zuizhong = kong(end);
        System.out.printf("最终效果为:%s",zuizhong);
        sc.close();
    }
    public static String kaHao(){
        // 输入验证
        boolean flag = true;
        String kaHao = "";
        while (flag){
            System.out.print("银行卡号:");
            kaHao = sc.nextLine();
            // 判断是否为数字
            for (int i = 0; i < kaHao.length(); i++) {
                if (kaHao.charAt(i) >= '0' && kaHao.charAt(i) <= '9') {
                    flag = false;
                }else {
                    flag = true;
                    break;
                }
            }
            // 判断长度是否为1
            if (kaHao.length() != 16){
                flag = true;
            }
            // 提示用户输入是否正确
            if (flag){
                System.out.println("请输入正确银行卡号!");
            }else {
                System.out.println("输入成功!");
            }
        }
        
        return kaHao;
    }
    public static String shuCu(String kahao){
        // 输出带星号的银行卡号
        String qian = kahao.substring(0,4);
        String hou = kahao.substring(12);
        String zhong = kahao.substring(4,12);
        for (int i = 0; i < zhong.length(); i++) {
            zhong = zhong.replace(zhong.charAt(i),'*');
        }
        return qian + zhong + hou;
    }
    public static String kong(String end){
        // 满足在输出时，要求每4位后面加一个空格，变成 XXXX **** **** XXXX 的格式。
        String jieguo = "";
        int count = 0;
        for (int i = 0; i < end.length(); i++) {
            count++;
            if(count == 4){
                count = 0;
                jieguo += end.charAt(i) + (i == end.length() - 1?"":" ");
            }else {
                jieguo += end.charAt(i);
            }
        }
        return jieguo;
    }
}