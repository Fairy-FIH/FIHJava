public class xiaomi {
    public static void main(String[] args) {
        shenfenzheng sfz = new shenfenzheng("321281202001011234");
        String csnian = sfz.getShenfenzheng().substring(6,10);
        String csyue = sfz.getShenfenzheng().substring(10,12);
        String csri = sfz.getShenfenzheng().substring(12,14);
        System.out.printf("出生年月是:%s年%s月%s日\n",csnian,csyue,csri);
        int xb = sfz.getShenfenzheng().charAt(16) - '0';
        if(xb % 2 == 0){
            System.out.println("性别是:女");
        }else {
            System.out.println("性别是:男");
        }

    }
}