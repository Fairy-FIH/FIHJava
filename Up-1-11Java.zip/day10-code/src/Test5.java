/*
给定两个字符串,A和B.
A的旋转操作就是将 A最左边的字符移动到最右边。
例如,若 A='abcde'，在移动一次之后结果就是'bcdea'
如果在若干次调整操作之后，A能变成B，那么返回True。
如果不能匹配成功，则返回false
 */

public class Test5 {
    public static void main(String[] args) {
        String A = "abcde";
        String B = "eabcd";
        System.out.println(pd(A,B));
    }
    public static boolean pd(String A, String B) {
        for (int i = 0; i < A.length(); i++) {
            A = bh(A);
            System.out.println(A);
            if (A.equals(B)){
                return true;
            }
        }
        return false;
    }
    public static String bh(String A){
        char qian = A.charAt(0);
        String zj = A.substring(1);
        return zj + qian;
    }
}