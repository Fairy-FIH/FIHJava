/*给定两个以字符串形式表示的非负整数num1和num2，
返回num1和num2的乘积，
它们的乘积也表示为字符串形式
注意:需要用己有的知识完成。*/

public class newnewTest {
    public static void main(String[] args) {
        String num1 = "92535";
        String num2 = "140";
        System.out.println(zz(num1, num2));
    }
    public static String zz(String num1,String num2){
        int sum1= 0;
        for(int i = 0;i < num1.length();i++){
            sum1 = sum1 * 10 + num1.charAt(i) - '0';
        }
        int sum2= 0;
        for(int i = 0;i < num2.length();i++){
            sum2 = sum2 * 10 + num2.charAt(i) - '0';
        }
        return (sum1*sum2) + "";
    }
}