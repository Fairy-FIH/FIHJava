import java.util.Scanner;

public class Demo4 {
    public static void main(String[] args) {
        /* 需求:键盘录入一个字符串，使用程序实现在控制台遍历该字符串(还可以实现字符串反转) */
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入字符串:");
        String str = sc.nextLine();
        char[] cd = new char[str.length()];
        for (int i = 0; i < str.length(); i++) {
            cd[i] = str.charAt(i);
        }
        for (int i = 0,j = cd.length - 1; i < j; i++,j--) {
            char temp = cd[j];
            cd[j] = cd[i];
            cd[i] = temp;
        }
        System.out.print("遍历加反转后:");
        for (int i = 0; i < cd.length; i++) {
            System.out.print(cd[i]);
        }
    }
}