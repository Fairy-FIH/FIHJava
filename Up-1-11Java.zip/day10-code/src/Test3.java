/* 该方法已遗弃 */


import java.util.Scanner;

public class Test3 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.print("请输入金额(7位):");
        String userinput = sc.nextLine();
        String[] zhong = jine(userinput);
        char[] zhonng1 = new char[zhong.length];
        for (int i = 0; i < zhong.length; i++) {
            zhonng1[i] = zhong[i].charAt(i);
        }
        char[] end = zhongwen(zhonng1);
        for (int i = 0; i < zhonng1.length; i++) {
            System.out.print(zhonng1[i]);
        }
    }
    public static String[] jine(String userinput){
        String[] danwei = new String[]{"元", "拾", "佰", "仟", "万", "拾", "佰", "仟", "亿"};
        String[] zuizhong = new String[userinput.length()];
        for (int i = 0; i < userinput.length(); i++) {
            char num = userinput.charAt(userinput.length() - 1 - i);
            zuizhong[i] = num + danwei[i];
        }
        for(int i = 0,j = zuizhong.length -1;i < j; i++,j--){
            String temp = zuizhong[i];
            zuizhong[i] = zuizhong[j];
            zuizhong[j] = temp;
        }
        return zuizhong;

    }
    public static char[] zhongwen(char[] zhuanhuan) {
        char[] Chinese = new char[zhuanhuan.length];
        for (int i = 0; i < zhuanhuan.length; i++) {
            if (zhuanhuan[i] == '1') {
                Chinese[i] = '壹';
            }else if (zhuanhuan[i] == '2') {
                Chinese[i] = '贰';
            }else if (zhuanhuan[i] == '3') {
                Chinese[i] = '叁';
            }else if (zhuanhuan[i] == '4') {
                Chinese[i] = '肆';
            }else if (zhuanhuan[i] == '5') {
                Chinese[i] = '伍';
            }else if (zhuanhuan[i] == '6') {
                Chinese[i] = '陆';
            }else if (zhuanhuan[i] == '7') {
                Chinese[i] = '柒';
            }else if (zhuanhuan[i] == '8') {
                Chinese[i] = '捌';
            }else if (zhuanhuan[i] == '9') {
                Chinese[i] = '玖';
            }else if (zhuanhuan[i] == '0') {
                Chinese[i] = '零';
            }
        }
        return Chinese;
    }

}