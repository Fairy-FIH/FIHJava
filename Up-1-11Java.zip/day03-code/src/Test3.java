// 需求:1.包含5这个数字(输入两次) 2.可以与5整除 3.正确返回true,非正确返回false

import java.util.Scanner;

public class Test3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入数字");
        int a = sc.nextInt();
        System.out.println("请输入数字");
        int b = sc.nextInt();

        boolean fanhui = (a == 5 | a ==5)  | (a + b) % 5 ==0;

        System.out.println(fanhui);
    }
}