import java.util.Scanner;


public class LogicoperatorTest1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("第一个值:");
        int a = sc.nextInt();
        System.out.println("第二个值:");
        int b = sc.nextInt();

        boolean result = (a == 6 || b == 6 || (a + b) % 6 == 0);
//        boolean result1 = (a + b) % 6 == 0;




        System.out.println( "\t" + result);
//        System.out.println("你输入的数字是6的倍数-----" + "\t" + result1);

    }
}