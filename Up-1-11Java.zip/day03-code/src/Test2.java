import java.util.Scanner;

public class Test2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = 10;
        a++;
        System.out.println(a);
        ++a;
        System.out.println(a);
        --a;
        System.out.println(a);
        a--;
        System.out.println(a);
    }
}