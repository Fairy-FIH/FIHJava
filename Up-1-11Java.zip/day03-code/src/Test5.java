import java.util.Scanner;

public class Test5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int a = 150;
        int b = 210;
        int c = 165;

        int Temp1 = (a > b) ? a : b;
//        int Temp2 = (a > c) ? a : c;
        int Temp3 = (Temp1 > c ) ? Temp1 : c;

        System.out.println(Temp3);
    }
}