import java.util.Scanner;

public class YuehuiTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("你的时髦分数:");
        int a = sc.nextInt();
        System.out.println("对方的时髦分数:");
        int b = sc.nextInt();


//        if (a > b){
//            System.out.println("你的时髦分数高");
//        }else if (a < b){
//            System.out.println("对方时髦分数高");
//        }



        System.out.println(a > b);


    }
}