import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int a = 10;
        int b = 10;
        int c = 20;

        System.out.println(a == b);
        System.out.println(a == c);

        System.out.println(a != b);
        System.out.println(a != c);

    }
}