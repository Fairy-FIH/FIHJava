import java.util.Scanner;

public class aritmeticoperator1 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入三个数");
        int a = sc.nextInt();

        System.out.println("百位是:" + (a / 100 % 10));
        System.out.println("十位是:" + (a / 10 % 10));
        System.out.println("个位是:" + (a % 10));

    }

}