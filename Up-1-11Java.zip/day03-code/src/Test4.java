import java.util.Scanner;

public class Test4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = 200;
        int b = 10;

        System.out.println(a & b);
    }
}