// 要求:1.输入两个数字 2.包含8 3.可以与8整除

import java.util.Scanner;

public class LogicoperatorTest2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入第一个字");
        int a = sc.nextInt();
        System.out.println("输入第二个字");
        int b = sc.nextInt();

        boolean result = (a == 8 || b == 8) || (a + b) % 8 == 0;

        System.out.println(result);


    }
}