import java.util.Scanner;

public class Demo1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入数字");
        int a = sc.nextInt();
        System.out.println("输入数字");
        int b = sc.nextInt();

        int yunSuan = (a > b) ? a : b;

        System.out.println(yunSuan);
    }
}