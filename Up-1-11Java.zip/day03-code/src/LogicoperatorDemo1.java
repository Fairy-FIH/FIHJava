
public class LogicoperatorDemo1 {
    public static void main(String[] args) {
      System.out.println(true & true);
      System.out.println(false & false);
      System.out.println(true & false);
      System.out.println(false & true);


      System.out.println("----------------------");

      System.out.println(true | true);
      System.out.println(false | false);
      System.out.println(true | false);
      System.out.println(false | true);

      System.out.println("----------------------");

      System.out.println(true ^ true);
      System.out.println(false ^ false);
      System.out.println(true ^ false);
      System.out.println(false ^ true);

      System.out.println("----------------------");

      System.out.println(!true);
      System.out.println(!false);

      System.out.println("----------------------");

      System.out.println(true && true);
      System.out.println(false && false);
      System.out.println(true && false);
      System.out.println(false && true);

      System.out.println("----------------------");

      System.out.println(true || true);
      System.out.println(false || false);
      System.out.println(true || false);
      System.out.println(false || true);

      System.out.println("----------------------");

      int q = 10;
      int w = 10;

      boolean result =  ++q < 5 & ++w < 5;
      System.out.println(result);
      System.out.println(q);
      System.out.println(w);

    }
}