import java.util.Scanner;

public class aritmeticoperator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println(10 / 2);
        System.out.println(10.0 / 3);

        System.out.println(10 % 4);

        System.out.println("输入第一个字");
        int a = sc.nextInt();
        System.out.println("输入第二个字");
        int b = sc.nextInt();
        System.out.println("余数是:" + (a % b));



//        System.out.println("请输入计算数值");
//        int a = sc.nextInt();
//        System.out.println("请输入第二个计算数值");
//        int b = sc.nextInt();
//
//        System.out.println("你的计算结果是:" + (a - b));
    }
}