import java.util.Scanner;

public class ScannerDemo2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入数字");
        short a = sc.nextShort();
        System.out.println(a);

    }
}