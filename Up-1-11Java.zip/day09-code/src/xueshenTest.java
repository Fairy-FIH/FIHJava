import java.util.Scanner;

public class xueshenTest {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        xueshen[] xs = new xueshen[4];
        xs[0] = new xueshen(1,"老王",21);
        xs[1] = new xueshen(2,"小周",20);
        xs[2] = new xueshen(3,"阿乔",22);
        xueshen xs1 = new xueshen(4,"阿明",23);
        int count = 0;
        for(xueshen s : xs){
            if(s != null)count++;
        }
        xueshen[] newarr;
        if(count < xs.length){
            newarr = manzu1(xs,xs1);
        }else {
            newarr = manzu(xs,xs1);
        }

        for (int i = 0; i < newarr.length; i++) {
            newarr[i].print();
            System.out.println();
        }
        while(true){
            System.out.println("请输入删除的对象(编号)");
            int shuru = sc.nextInt();
            boolean flag = false;
            for (int i = 0; i < newarr.length; i++) {
                if (newarr[i].getBianho() == shuru) {
                    newarr[i] = null;
                    flag = true;
                }
            }
            if(flag){
                System.out.println("删除成功!");
                break;
            }else {
                System.out.println("删除失败!");
            }
        }
        System.out.println();
        for (int i = 0; i < newarr.length; i++) {
            if(newarr[i] != null){
                newarr[i].print();
                System.out.println();
            }
        }
        System.out.println();
        for (int i = 0; i < newarr.length; i++) {
            if (newarr[i] != null && newarr[i].getBianho() == 2) {
                System.out.println("编号为2的学生年龄增加1已完成");
                newarr[i].setAge(newarr[i].getAge() + 1);
            }
        }
        System.out.println();
        for (int i = 0; i < newarr.length; i++) {
            if(newarr[i] != null){
                newarr[i].print();
                System.out.println();
            }
        }

    }
    public static xueshen[] manzu1(xueshen[] arr,xueshen a){
        for(int i=0;i<arr.length;i++){
            if (arr[i] == null){
                arr[i]=a;
                break;
            }
        }
        return arr;
    }
    public static xueshen[] manzu(xueshen[] arr,xueshen a){
        xueshen[] xs = new xueshen[arr.length + 1];
        for(int i=0;i<arr.length;i++){
            xs[i] = arr[i];
        }
        xs[arr.length] = a;
        return xs;
    }
}