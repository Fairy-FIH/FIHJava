import java.util.Scanner;

public class sp {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
/*
需求:定义数组存储3个商品对象。
商品的属性:商品的id，名字，价格，库存。
创建三个商品对象，并把商品对象存入到数组当中
*/
        shangping[] sp = new shangping[3];
        // 提供用户录入数据;
//        for (int i = 0; i < sp.length; i++) {
//            sp[i] = new shangping();
//            System.out.print("请输入商品"+(i+1)+"的id:");
//            sp[i].setId(sc.next());
//            System.out.print("请输入商品"+(i+1)+"的名字:");
//            sp[i].setName(sc.next());
//            System.out.print("请输入商品"+(i+1)+"的价格:");
//            sp[i].setjiage(sc.nextDouble());
//            System.out.print("请输入商品"+(i+1)+"的库存量:");
//            sp[i].setKucun(sc.nextInt());
//        }
        // 固定数据;
        sp[0] = new shangping("00x101","叮咚鸡",19.9,10);
        sp[1] = new shangping("00x102","大狗叫",100,5);
        sp[2] = new shangping("00x103","哈基米",99,3);
        System.out.println();
        // 调用显示方法
//        for (int i = 0; i < sp.length; i++) {
//            System.out.print("商品"+(i+1)+"的信息:"+"\n");
//            sp[i].xianshi();
//            System.out.println();
//        }
        // main方法中直接拿数据
        for (int i = 0; i < sp.length; i++) {
            System.out.printf("商品编号是:%s\n"+"商品名字是:%s\n"+"商品价格是:%.2f\n"+"商品库存余量有:%s\n",
                    sp[i].getId(),
                    sp[i].getName(),
                    sp[i].getJiage(),
                    sp[i].getKucun()
            );
            System.out.println();
        }
        sc.close();
    }
}