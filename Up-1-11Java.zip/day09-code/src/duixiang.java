public class duixiang {
    public static void main(String[] args) {
        crush[] c = new crush[4];
        c[0] = new crush("小红",18,'女',"画画,睡觉");
        c[1] = new crush("小白",17,'女',"吃好吃的,打游戏");
        c[2] = new crush("小黑",20,'男',"打游戏,睡觉");
        c[3] = new crush("小蓝",17,'女',"cos,打游戏");
        int sum = 0;
        for(crush dx : c){
            sum += dx.getAge();
        }
        int avg = sum / c.length;
        System.out.println("平均年龄:"+ avg);
        System.out.println();
        int count = 0;
        for(int i = 0; i < c.length;i++){
            if(c[i].getAge() < avg){
                count++;
            }
        }

        System.out.printf("比平均年龄低的有:%s个",count);
        System.out.println();
        System.out.println("分别是:");
        for(crush dx : c){
            if(dx.getAge() < avg){
                dx.print();
                System.out.println();
            }
        }
    }
}