public class xueshen {
    private int bianho;
    private String name;
    private int age;

    public xueshen(){}
    public xueshen(int bianho, String name, int age) {
        this.bianho = bianho;
        this.name = name;
        this.age = age;
    }
    public void print(){
        System.out.println("编号:" + this.bianho);
        System.out.println("名字:" + this.name);
        System.out.println("年龄:" + this.age);
    }

    public int getBianho() {
        return bianho;
    }

    public void setBianho(int bianho) {
        this.bianho = bianho;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}