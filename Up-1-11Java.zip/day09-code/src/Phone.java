public class Phone {
    private String pinpai;
    private double jiage;
    private String color;

    public Phone(){}
    public Phone(String pinpai, double jiage, String color) {
        this.pinpai = pinpai;
        this.jiage = jiage;
        this.color = color;
    }
    public void setPinpai(String pinpai){
        this.pinpai = pinpai;
    }
    public void setJiage(double jiage){
        this.jiage = jiage;
    }
    public void setColor(String color){
        this.color = color;
    }
    public String getPinpai(){
        return this.pinpai;
    }
    public double getJiage(){
        return this.jiage;
    }
    public String getColor(){
        return this.color;
    }
}