import java.util.Random;

public class Role {
    private String name;
    private int hp;
    private String sex = "男";
    private String looks = "气宇轩昂";
    private String[] gjzs = new String[]{
            "龙吟九天","星河破碎诀","次元斩断剑","雷霆万钧斩","九阳神功","时间逆流术","心灵感应波","乾坤大挪移"
    };
    private static Random ran = new Random();

    public Role(){}
    public Role(String name, int hp){
        this.name = name;
        this.hp = hp;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setHp(int hp){
        this.hp = hp;
    }
    public String getName(){
        return name;
    }
    public int getHp(){
        return hp;
    }
    /*
    [攻击模块]
    谁攻击谁?
    对象1攻击对象2
    */
    // 该方法调用者谁?-----this
    public void attack(Role underattack){
        int sh = ran.nextInt(1,51);
        underattack.setHp(underattack.getHp() - sh);
        if(underattack.getHp() <= 0){
            underattack.setHp(0);
        }
        String gjmz = gjzs[ran.nextInt(gjzs.length)];
        System.out.println(this.name+"使出了一招["+gjmz+"],飞起来打了"+underattack.getName()+"一下,造成了"+sh+"伤害,"+underattack.getName()+"还剩"+underattack.getHp()+"血量");
    }
    public void baoji(Role underattack){
        int sh = 100;
        underattack.setHp(underattack.getHp() - sh);
        if(underattack.getHp() <= 0){
            underattack.setHp(0);
        }
        System.out.println(this.name+"打了"+underattack.getName()+"一下,(暴击!)造成了"+sh+"伤害,"+underattack.getName()+"还剩"+underattack.getHp()+"血量");
    }


}