import java.util.Random;

public class xinxi {
    private String name;
    private int hp;
    private char sex;
    private String face;
    private static String[] boyface = new String[]{"棱角分明", "面如冠玉", "五官端正", "双瞳剪水", "神采奕奕", "目若朗星", "目光如炬"};
    private static String[] grilface = new String[]{"清丽脱俗", "眉目如画", "冰清玉洁", "英气逼人", "飒爽英姿", "温婉贤淑", "楚楚动人"};
    private Random rand = new Random();
    static String[] attacks_desc = {
            "%s使出了一招【背心钉】，转到对方的身后，一掌问%s背心的灵台穴拍去。",
            "%s使出了一招【游空探爪】，飞起身形自半空中变掌为抓锁向%s。",
            "%s大喝一声，身形下伏，一招【劈雷坠地】，捶向%s双腿。",
            "%s运气于掌，一瞬问掌心变得血红，一式【掌心雷】，推向%s。",
            "%s阴手翻起阳手跟进，一招【没遮拦】，结结实实的锤向%s。",
            "%s上步抢身，招中套招，一招【劈挂连环】，连环攻向%s。"
    };
    static String[] injureds_desc = {
            "结果%s退了半步，毫发无损",
            "结果给%s造成一处瘀伤",
            "结果一击命中，%s痛得弯下腰",
            "结果%s痛苦地闷哼了一声，显然受了点内伤",
            "结果%s摇摇晃晃，一跤摔倒在地",
            "结果%s脸色一下变得惨白，连退了好几步",
            "结果「轰」的一声，%s口中鲜血狂喷而出",
            "结果%s一声惨叫,像滩软泥一样塌了下去"
    };

    public xinxi() {
    }

    public xinxi(String name, int hp, char sex) {
        this.name = name;
        this.hp = hp;
        this.sex = sex;
        if (sex == '男') {
            this.face = boyface[rand.nextInt(boyface.length)];
        } else {
            this.face = grilface[rand.nextInt(grilface.length)];
        }
    }

    public void xainshi() {
        System.out.println("姓名为:" + this.name);
        System.out.println("血量为:" + this.hp);
        System.out.println("性别为:" + this.sex);
        System.out.println("长相为:" + this.face);

    }

    public void attack(xinxi underattack) {
        // 定义范围0~5
        int index = rand.nextInt(attacks_desc.length);
        // 将这个范围的字符串随机种子赋值给KunFu
        String KunFu = attacks_desc[index];
        // 打印获得到的字符串,将攻击发起者,受害人串联
        System.out.printf(KunFu, this.getName(), underattack.name);
        // 随机每次攻击伤害
        int sh = rand.nextInt(1, 51);
        // 被攻击者的血量更新为(获得到的血量减去攻击伤害)
        underattack.setHp(underattack.getHp() - sh);
        // 如果被攻击者血量低于或等于0,将血量更新为0;
        if (underattack.getHp() <= 0) {
            underattack.setHp(0);
        }
        // 定义一个血条,这个血条的值为被攻击者血量除于10,获得一个(0~10的范围)
        int xuet = underattack.getHp() / 10;
//        if (underattack.getHp() >= 90) {
//            System.out.printf(injureds_desc[0], underattack.getName());
//        } else if (underattack.getHp() >= 80 && underattack.getHp() < 90) {
//            System.out.printf(injureds_desc[1], underattack.getName());
//        } else if (underattack.getHp() >= 70 && underattack.getHp() < 80) {
//            System.out.printf(injureds_desc[2], underattack.getName());
//        } else if (underattack.getHp() >= 60 && underattack.getHp() < 70) {
//            System.out.printf(injureds_desc[3], underattack.getName());
//        } else if (underattack.getHp() >= 50 && underattack.getHp() < 60) {
//            System.out.printf(injureds_desc[4], underattack.getName());
//        } else if (underattack.getHp() >= 30 && underattack.getHp() < 50) {
//            System.out.printf(injureds_desc[5], underattack.getName());
//        } else if (underattack.getHp() >= 10 && underattack.getHp() < 30) {
//            System.out.printf(injureds_desc[6], underattack.getName());
//        } else if (underattack.getHp() == 0) {
//            System.out.printf(injureds_desc[7], underattack.getName());
//        }
        // 如果被攻击者血量为0时,打印injureds_desc数组中最后一个索引
        if (underattack.getHp() == 0) {
            System.out.printf(injureds_desc[7], underattack.getName());
        }else {
            // 按照血条的值打印话句
            switch (xuet) {
                case 10, 9:
                    System.out.printf(injureds_desc[0], underattack.getName());
                    break;
                case 8:
                    System.out.printf(injureds_desc[1], underattack.getName());
                    break;
                case 7:
                    System.out.printf(injureds_desc[2], underattack.getName());
                    break;
                case 6:
                    System.out.printf(injureds_desc[3], underattack.getName());
                    break;
                case 5:
                    System.out.printf(injureds_desc[4], underattack.getName());
                    break;
                case 4, 3:
                    System.out.printf(injureds_desc[5], underattack.getName());
                    break;
                case 2, 1:
                    System.out.printf(injureds_desc[6], underattack.getName());
                    break;
            }
        }
        // 换行
        System.out.println();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public char getSex() {
        return sex;
    }

    public void setSex(char sex) {
        this.sex = sex;
    }

    public String getFace() {
        return face;
    }

    public void setFace(String face) {
        this.face = face;
    }
}
