import java.util.Random;

public class game{
    public static void main(String[] args){
        guy g1 = new guy("乔峰",100);
        guy g2 = new guy("鸠摩智",100);
        System.out.println("游戏开始!");
        System.out.printf("%s你%s好%s","哈基米",1,"开什么玩笑");



//        while(g2.win() && g1.win()){
//            g1.attick(g2);
//            g2.attick(g1);
//        }



//        boolean flag = win(g1, g2);
//        while(flag){
//            js h1 = new js();
//            js h2 = new js();
//            p1 -=  h1.getSjsz();
//            System.out.println(g1.getName() + "举起拳头打了" + g2.getName() + "一下，造成了" + h1.getSjsz() + "点伤害." + g2.getName() + "还剩下" + p1 + "点血");
//            p2 -= h2.getSjsz();
//            System.out.println(g2.getName() + "举起拳头打了" + g1.getName() + "一下，造成了" + h2.getSjsz() + "点伤害." + g1.getName() + "还剩下" + p2 + "点血");
//        }
//        for (int i = 0;i < 10;){
//            js h1 = new js();
//            js h2 = new js();
//            p1 -=  h1.getSjsz();
//            System.out.println(g1.getName() + "举起拳头打了" + g2.getName() + "一下，造成了" + h1.getSjsz() + "点伤害." + g2.getName() + "还剩下" + p1 + "点血");
//            p2 -= h2.getSjsz();
//            System.out.println(g2.getName() + "举起拳头打了" + g1.getName() + "一下，造成了" + h2.getSjsz() + "点伤害." + g1.getName() + "还剩下" + p2 + "点血");
//            if (p1 < 0){
//                System.out.println(g2.getName() + "游戏失败");
//                System.out.println(g1.getName()+ "KO了" + g2.getName());
//                System.out.println("共循环" + count + "次");
//                return;
//            }else if (p2 < 0){
//                System.out.println(g1.getName() + "游戏失败");
//                System.out.println(g2.getName()+ "KO了" + g1.getName());
//                System.out.println("共循环" + count + "次");
//                return;
//            }
//            else {
//                i++;
//                count++;
//            }
//        }
//        System.out.println("共循环" + count + "次");
//        System.out.println(g1.getName() + "举起拳头打了" + g[1].getName() + "一下，造成了" + sjs + "点伤害." + g[1].getName() + "还剩下" + jmzshenyu + "点血");
//
//        int qfshenyu = g[0].getHp() - sjq;
//
//        System.out.println(g[1].getName() + "举起拳头打了" + g[0].getName() + "一下，造成了" + sjq + "点伤害." + g[0].getName() + "还剩下" + qfshenyu + "点血");
//
//        if (g[0].getHp() < 0 || g[1].getHp() < 0){
//            System.out.println("游戏失败");
//        }
    }
}