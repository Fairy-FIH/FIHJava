import java.util.Scanner;

public class index {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        String a1 = sc.next();
        System.out.println(a1);
        String a2 = sc.next();
        System.out.println(a2);

//        String h1 = sc.nextLine();
//        System.out.println(h1);
//        String h2 = sc.nextLine();
//        System.out.println(h2);
    }
}