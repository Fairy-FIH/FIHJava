public class car {
    private String pingpai;
    private double jiage;
    private String color;

    public car(){}
    public car(String pingpai, double jiage, String color) {
        this.pingpai = pingpai;
        this.jiage = jiage;
        this.color = color;
    }

    public String getPingpai() {
        return pingpai;
    }

    public void setPingpai(String pingpai) {
        this.pingpai = pingpai;
    }

    public double getJiage() {
        return jiage;
    }

    public void setJiage(double jiage) {
        this.jiage = jiage;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}