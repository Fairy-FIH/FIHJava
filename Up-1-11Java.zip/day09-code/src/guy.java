import java.util.Random;

public class guy {
    private String name;
    private int hp;
    private static Random rand = new Random();

    public guy(){
    }
    public guy(String name, int hp){
        this.name = name;
        this.hp = hp;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setHp(int hp){
        this.hp = hp;
    }
    public String getName(){
        return name;
    }
    public int getHp(){
        return hp;
    }
    public int sh(){
        return rand.nextInt(1,91);
    }
//    public void gongji(guy a,guy b){
//        int sh = sh();
//        this.hp = (a.getHp()-sh);
//        System.out.println(a.getName() + "举起拳头打了" + b.getName() + "一下，造成了" + sh + "点伤害." + b.getName() + "还剩下" + hp + "点血");
//    }
    public void attick(guy underattick){
        int sh = sh();
        underattick.setHp(underattick.getHp() - sh);
        System.out.println(this.name + "举起拳头打了" + underattick.getName() + "一下，造成了" + sh + "点伤害." + underattick.getName() + "还剩下" + underattick.getHp() + "点血");
    }
    public boolean  win(){
        if(this.getHp() <= 0){
            System.out.println(this.name + "输了");
            return false;
        }
        return true;
    }
}