import java.util.Scanner;

public class studentTest{
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        student[] stu = new student[4];
//        stu[0] = new student("小白",1001,18);
//        stu[1] = new student("小黑",1002,17);
//        stu[2] = new student("小紫",1003,19);
        stu[3] = new student();
        System.out.printf("当前系统共存储%s名学生\n",3);
        System.out.printf("请添加第%s名学生数据\n",4);
        while(true){
            System.out.print("请输入学号:");
            int s = sc.nextInt();
            if(!panduan(stu,s)){
                System.out.println("已添加该学生数据");
                stu[3].setXuehao(s);
                break;
            }else {
                System.out.println("已有该学号,请重新输入!");
            }
        }
        System.out.println();
        System.out.println("所有学生数据:");
        for(student s : stu){
            s.print();
            System.out.println();
        }
        System.out.println();
        System.out.println("==强制要求!==请通过学号删除学生数据!");
        while(true){
            boolean flag = false;
            System.out.print("请输入学号:");
            int userxuehao = sc.nextInt();
            for (int i = 0; i < stu.length; i++) {
                if(stu[i].getXuehao() == userxuehao){
                    stu[i].setXuehao(0);
                    flag =  true;
                }
            }
            if(flag){
                System.out.println("删除成功!");
                break;
            }else {
                System.out.println("删除失败!");
            }
        }

        System.out.println();
        System.out.println("当前学生信息:");
        for(student s : stu){
            s.print();
            System.out.println();
        }
        System.out.println();
        // 查询数组为1002的学生,如果存在,年龄+1
        for(student s : stu){
            if(s.getXuehao() == 1002){
                s.setAge(s.getAge()+1);
            }
        }

        System.out.println("最终学生情况:");
        for(student s : stu){
            s.print();
            System.out.println();
        }
        sc.close();

    }
    public static boolean panduan(student[] shuzu,int shuru){
        for (int i = 0; i < shuzu.length; i++) {
            if(shuzu[i].getXuehao() == shuru){
                return true;
            }
        }
        return false;
    }
}