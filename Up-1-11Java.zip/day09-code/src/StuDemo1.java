public class StuDemo1 {
    public static void main(String[] args) {
        student[] stu = new student[3];
        stu[0] = new student(1,"小白",18);
        stu[1] = new student(2,"小黑",17);
        stu[2] = new student(3,"小紫",19);

        student stu1 = new student(4,"小周",19);

        boolean flag = pd(stu,stu1.getXuehao());
        if(flag){
            System.out.println("当前学号重复");
        }else {
            int count = getcount(stu);
            if(count == stu.length){
                student[] newarr = creatnewarr(stu);
                newarr[count] = stu1;
            }else {
                stu[count] = stu1;
            }
        }
        for(int i=0;i<stu.length;i++){
            stu[i].print();
            System.out.println();
        }
    }
    public static student[] creatnewarr(student[] arr){
        student[] stu = new student[arr.length+1];
        for(int i=0;i<arr.length;i++){
            stu[i] = arr[i];
        }
        return stu;
    }
    public static int getcount(student[] arr){
        int count = 0;
        for(int i=0;i<arr.length;i++){
            if(arr[i]!=null){
                count++;
            }
        }
        return count;
    }
    public static boolean pd(student[] arr,int a){
        for(int i = 0;i < arr.length;i++){
            if (arr[i].getAge() == a){
                return true;
            }
        }
        return false;
    }
}