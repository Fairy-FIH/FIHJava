import java.util.Random;

public class newgame{
    public static void main(String[] args){
        Role r1 = new Role("乔峰",100);
        Role r2 = new Role("鸠摩智",100);
        System.out.println("游戏开始");
        while(true){
            r1.attack(r2);
            if (!gameover(r2)) break;
            r2.attack(r1);
            if (!gameover(r1)) break;
//            if(gl() == 0){
//                if(bj() == 1) {
//                    r1.baoji(r2);
//                    if (!gameover(r2)) break;
//
//                }else {
//                    r1.attack(r2);
//                    if (!gameover(r2)) break;
//                    r2.attack(r1);
//                    if (!gameover(r1)) break;
//                }
//            } else if (gl() == 1) {
//                if(bj() == 1) {
//                    r2.baoji(r1);
//                    if (!gameover(r1)) break;
//                }
//                else {
//                    r2.attack(r1);
//                    if (!gameover(r1)) break;
//                    r1.attack(r2);
//                    if (!gameover(r2)) break;
//
//                }
//            }
        }
    }
    public static boolean gameover(Role a1){
        if (a1.getHp() == 0) {
            System.out.println(a1.getName() + "失败");
            return false;
        }
        return true;
    }
    public static int gl(){
        Random r = new Random();
        int gl = r.nextInt(2);
        return gl;
    }
    public static int bj(){
        Random r = new Random();
        int bj = r.nextInt(0,11);
        return bj;
    }
}