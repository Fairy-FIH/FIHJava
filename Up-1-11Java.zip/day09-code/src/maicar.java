import java.util.Scanner;

public class maicar {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        car[] c = new car[3];
        for (int i = 0; i < c.length; i++) {
            c[i] = new car();
            System.out.print("品牌:");
            c[i].setPingpai(sc.next());
            System.out.print("价格:");
            c[i].setJiage(sc.nextDouble());
            System.out.print("颜色:");
            c[i].setColor(sc.next());
        }
        System.out.println();
        for(car che : c){
            System.out.printf("品牌为:%s\n"+"价格为:%.2f\n"+"颜色为:%s\n",
                    che.getPingpai(),
                    che.getJiage(),
                    che.getColor()
            );
            System.out.println();
        }
        sc.close();
    }
}