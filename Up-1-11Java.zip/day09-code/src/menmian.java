public class menmian {
    public static void main(String[] args) throws InterruptedException {
        xinxi x1 = new xinxi("东方不败", 100, '男');
        xinxi x2 = new xinxi("楚留香", 100, '女');
        x1.xainshi();
        System.out.println();
        x2.xainshi();
        System.out.println();
        while (true) {
            Thread.sleep(500);
            x1.attack(x2);
            if (x2.getHp() <= 0) {
                System.out.println(x1.getName() + "KO了" + x2.getName());
                break;
            }
            Thread.sleep(500);
            x2.attack(x1);
            if (x1.getHp() <= 0) {
                System.out.println(x2.getName() + "KO了" + x1.getName());
                break;
            }
        }
    }
}