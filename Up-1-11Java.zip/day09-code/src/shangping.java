public class shangping {
    private String id;
    private String name;
    private double jiage;
    private int kucun;

    public shangping() {}
    public shangping(String id, String name, double jiage, int kucun) {
        this.id = id;
        this.name = name;
        this.jiage = jiage;
        this.kucun = kucun;
    }
    public void xianshi(){
        System.out.println("商品ID编号是:"+this.id);
        System.out.println("商品名字是:"+this.name);
        System.out.println("商品价格是:"+this.jiage+"元");
        System.out.println("商品库存余量还有:"+this.kucun+"个");
    }

    public void setId(String id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setjiage(double jiage) {
        this.jiage = jiage;
    }
    public void setKucun(int kucun) {
        this.kucun = kucun;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getJiage() {
        return jiage;
    }

    public int getKucun() {
        return kucun;
    }
}