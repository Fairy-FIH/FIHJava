public class student {
    private String name;
    private int xuehao;
    private int age;

    public student() {}
    public student(int xuehao,String name, int age) {
        this.name = name;
        this.xuehao = xuehao;
        this.age = age;
    }
    public void print(){
        System.out.printf("姓名为:%s,学号为:%s,年龄为:%s",this.name,this.xuehao,this.age);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getXuehao() {
        return xuehao;
    }

    public void setXuehao(int xuehao) {
        this.xuehao = xuehao;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}