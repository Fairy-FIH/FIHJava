public class PhoneTest{
    public static void main(String[] args) {
        Phone[] p = new Phone[3];
        p[0] = new Phone("小米",3999,"白色");
        p[1] = new Phone("华为",5999,"黑色");
        p[2] = new Phone("三星",6999,"粉色");
        double sum = 0;
        for (Phone jg : p) {
            sum += jg.getJiage();
        }
        double avg = sum / p.length;
        System.out.printf("%.2f",avg);
    }
}