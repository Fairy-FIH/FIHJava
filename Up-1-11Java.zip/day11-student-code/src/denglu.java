import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class denglu {
    static ArrayList<zhanghu> ls = new ArrayList<>();
    static {
        zhanghu ceshi = new zhanghu("小王","1234","12345","12345678");
        ls.add(ceshi);
    }
    static Scanner sc = new Scanner(System.in);
    static char[] zf = {
            'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
            'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
    };
    static char[] hz = {'1', '2', '3', '4', '5', '6', '7', '8', '9','0'};
    public static void main(String[] args) {

        // 测试[账户信息]---2026年1月26已修改为静态代码块加载
//        ArrayList<zhanghu> List = new ArrayList<>();
//        zhanghu ceshi = new zhanghu("小王","1234","12345","12345678");
//        List.add(ceshi);

        System.out.println("---------欢迎来到学生管理系统登陆界面---------");
        loop : while (true){
            System.out.println("1,登录 2,注册 3,忘记密码");
            System.out.print("请选择操作:");
            String caozuo = sc.nextLine();
            hjm : switch (caozuo) {
                case "1":
                    if (denglujiemian(ls)){
                        break loop;
                    }
                    break;
                case "2":
                    zhuce(ls);
                    break;
                case "3":
                    wangjimima(ls);
                    break;
                default:
                    System.out.println("没有该选项!");
                    break;
            }
        }
        guanlixitong.chaxun();
    }
    // 判断用户名输入是否符合3~15和包含数字
    public static boolean panduanuser(String input){
        if (input.length() <3 || input.length() > 15){
            return false;
        }
        if(hzpanduan(input) && zfpanduan(input)){
            return true;
        }
        return false;
    }
    // 判断是否包含数字
    public static boolean hzpanduan(String input){
        for (int i = 0; i < input.length(); i++){
            for (int j = 0; j < hz.length; j++){
                if(input.charAt(i) == hz[j]){
                    return true;
                }
            }
        }
        return false;
    }
    // 判断是否包含英文(大小写)
    public static boolean zfpanduan(String input){
        for (int i = 0; i < input.length(); i++){
            for (int j = 0; j < zf.length; j++){
                if(input.charAt(i) == zf[j]){
                    return true;
                }
            }
        }
        return false;
    }

    // 判断两次密码是否一致
    public static boolean miampanduan(String password,String password2){
        if (password2.length() != password.length()){
            return false;
        }
        if (password2.equals(password)){
            return true;
        }
        return false;
    }
    // 身份证号码验证
    public static boolean shenfenzhen(String shenfen){
        // 长度18位,不能以0开头
        if (shenfen.length() != 18 || shenfen.charAt(0) == '0'){
            return false;
        }
        // 前16位必须为数字
        for (int i = 0; i < shenfen.length() - 2; i++){
            for (int j = 0; j < hz.length; j++){
                if (shenfen.charAt(i) < '0' || shenfen.charAt(i) > '9'){
                    return false;
                }
            }
        }
        char[] shenfz = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'X', 'x'};
        // 最后一位可以是数字,也可以是大写X或小写x
        for (int i = 0; i < shenfz.length; i++){
            if(shenfen.charAt(shenfen.length() - 1) == shenfz[i]){
                return true;
            }
        }
        return true;
    }
    // 手机号验证
    public static boolean phonejiaoyan(String input){
        if (input.length() != 11 || input.charAt(0) == '0'){
            return false;
        }
        for (int i = 0; i < input.length(); i++){
            if (input.charAt(i) < '0' || input.charAt(i) > '9'){
                return false;
            }
        }
        return true;
    }

// 注册功能
    public static void zhuce(ArrayList<zhanghu> list){
        zhanghu zh = new zhanghu();
        System.out.println("注册操作!");
        while (true){
            while (true){
                System.out.print("请输入用户名[在3~15位之间;不能是纯数字,只能是字母加数字的组合!]:");
                String user = sc.nextLine();
                boolean userpanduan = panduanuser(user);
                if (userpanduan){
                    System.out.println("该用户名可使用!已通过");
                    zh.setUser(user);
                    break;
                }else {
                    System.out.println("该用户名非法!");
                }
            }
            while (true){
                System.out.print("请输入密码:");
                String password = sc.nextLine();
                System.out.print("请再次输入密码:");
                String password2 = sc.nextLine();
                if (miampanduan(password,password2)){
                    System.out.println("密码已录入!");
                    zh.setPassword(password);
                    break;
                }else {
                    System.out.println("密码不一致");
                }
            }

            while (true){
                System.out.print("请输入身份证:");
                String shenfen = sc.nextLine();
                if (shenfenzhen(shenfen)){
                    System.out.println("身份证已录入!");
                    zh.setShnefen(shenfen);
                    break;
                }else {
                    System.out.println("身份证校验未通过");
                }
            }
            while (true){
                System.out.print("请输入手机号:");
                String phone = sc.nextLine();
                if (phonejiaoyan(phone)){
                    System.out.println("手机号已通过!");
                    zh.setPhone(phone);
                    break;
                }else {
                    System.out.println("手机号校验未通过");
                }
            }
            System.out.println("注册成功!");
            list.add(zh);
            break;
        }
    }

// 登录功能
    public static boolean denglujiemian(ArrayList<zhanghu> list){
        for (int i = 2; i >= 0; i--){
            System.out.print("请输入用户名:");
            String user = sc.nextLine();
            System.out.print("请输入密码:");
            String password = sc.nextLine();
            String yanzhengmass = yanzhengma();
            System.out.println(yanzhengmass);
            System.out.println("请输入验证码:");
            String yanzhenma = sc.nextLine();
            if (yanzhengmashuru(yanzhengmass,yanzhenma)){
                System.out.println("输入正确!");
                if (!zhanghaocunzai(list,user,password)){
                    System.out.println("该账户未注册");
                    break;
                }
                return true;
            }else {
                if (i == 0){
                    System.out.println("当前已无次数,请重新选择操作");
                }else {
                    System.out.println("当前还剩" + i + "次机会");
                }
                System.out.println("输入错误!");
            }
        }
        return false;
    }

    // 忘记密码(判断用户身份证和手机号是否一致,一致:提示输入新的密码进行修改.不一致:修改失败
    public static void wangjimima(ArrayList<zhanghu> list){
        while (true){
            System.out.print("请输入用户名:");
            String input = sc.nextLine();
            if (!yonghumingcunzai(list,input)){
                System.out.println("用户不存在");
                break;
            }
            System.out.print("请输入身份证号码:");
            String sfzhm = sc.nextLine();
            System.out.print("请输入手机号码:");
            String sjhm = sc.nextLine();
            int weizhi = sjhsfz(list,sfzhm,sjhm);
            if (sjhsfz(list,sfzhm,sjhm) == -1){
                System.out.println("账户信息不匹配,修改失败!");
                break;
            }else {
                System.out.println("请输入新的密码:");
                String newmima = sc.nextLine();
                list.get(weizhi).setPassword(newmima);
                System.out.println("修改成功!");
            }
            break;
        }
    }
    // 判断用户身份证和手机号是否一致
    public static int sjhsfz(ArrayList<zhanghu> list,String sfzhm,String sjhm){
        for (int i = 0; i < list.size(); i++){
            if (sfzhm.equals(list.get(i).getShnefen()) && sjhm.equals(list.get(i).getPhone())){
                return i;
            }
        }
        return -1;
    }

    // 判断用户名是否存在
    public static boolean yonghumingcunzai(ArrayList<zhanghu> list,String input){
        for (int i = 0;i < list.size();i++){
            if (input.equals(list.get(i).getUser())){
                return true;
            }
        }
        return false;
    }

    // 判断验证码是否输入正确
    public static boolean yanzhengmashuru(String yanzhengma,String input){
        if (input.equalsIgnoreCase(yanzhengma)){
            return true;
        }
        return false;
    }

    // 判断用户是否注册过账号
    public static boolean zhanghaocunzai(ArrayList<zhanghu> list,String user,String password){
        for (int i = 0; i < list.size(); i++){
            if (list.get(i).getUser().equals(user) && list.get(i).getPassword().equals(password)){
                return true;
            }
        }
        return false;
    }
    //验证码生成器
    public static String yanzhengma(){
        Random rand = new Random();
        StringBuilder yzm = new StringBuilder();
        StringBuilder end = new StringBuilder();
        for (int i = 0; i < 5; i++){
            int index = rand.nextInt(zf.length);
            yzm.append(zf[index]);
        }
        int index = rand.nextInt(5);
        int suiji = rand.nextInt(hz.length);
        char[] yzmm = yzm.toString().toCharArray();
        yzmm[index] = hz[suiji];
        for (int i = 0; i < yzmm.length; i++){
            end.append(yzmm[i]);
        }
        return end.toString();
    }

}