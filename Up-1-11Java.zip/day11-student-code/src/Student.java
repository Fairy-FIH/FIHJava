public class Student {
    private String id;
    private String name;
    private String age;
    private String zhuzhi;

    public Student(){}
    public Student(String id, String name, String age, String zhuzhi) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.zhuzhi = zhuzhi;
    }
    public void xinxi(){
        System.out.printf("ID:%s\t姓名:%s\t年龄:%s\t住址:%s\n",this.id,this.name,this.age,this.zhuzhi);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getZhuzhi() {
        return zhuzhi;
    }

    public void setZhuzhi(String zhuzhi) {
        this.zhuzhi = zhuzhi;
    }
}