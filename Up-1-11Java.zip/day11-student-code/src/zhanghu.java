public class zhanghu {
    private String user;
    private String password;
    private String shnefen;
    private String phone;

    public zhanghu(){}
    public zhanghu(String user, String password, String shnefen, String phone) {
        this.user = user;
        this.password = password;
        this.shnefen = shnefen;
        this.phone = phone;
    }
    public void xinxi(){
        System.out.printf("用户名:%s\t密码:%s\t身份证:%s\t手机号:%s\n",this.user,this.password,this.shnefen,this.phone);
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getShnefen() {
        return shnefen;
    }

    public void setShnefen(String shnefen) {
        this.shnefen = shnefen;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}