import java.util.ArrayList;
import java.util.Scanner;

public class guanlixitong {
    static Scanner sc = new Scanner(System.in);

    public static void chaxun() {
        ArrayList<Student> list = new ArrayList<>();
        System.out.println("---------欢迎来到学生管理系统---------");
        loop : while (true) {
            while (true) {
                System.out.println();
                System.out.println("1,添加学生数据");
                System.out.println("2,删除学生数据");
                System.out.println("3,查询学生数据");
                System.out.println("4,修改学生数据");
                System.out.println("5,退出");
                System.out.print("请选择:");
                String userinput = sc.nextLine();
                switch (userinput) {
                    case "1":
                        tianjia(list);
                        break;
                    case "2":
                        shanchu(list);
                        break;
                    case "3":
                        chaxun(list);
                        break;
                    case "4":
                        xiugai(list);
                        break;
                    case "5":
                        break loop;
                    default:
                        System.out.println("没有该选项!");
                }
            }
        }
        sc.close();
    }

    public static void tianjia(ArrayList<Student> list) {
        while (true) {
            String id;
            Student stu = new Student();
            while (true){
                System.out.print("请输入ID:");
                id = sc.nextLine();
                if (panduancunzai(list,id) == -1){
                    break;
                }else {
                    System.out.println("该ID已存在");
                }
            }
            stu.setId(id);
            System.out.print("输入姓名:");
            String name = sc.nextLine();
            stu.setName(name);
            System.out.print("输入年龄:");
            String age = sc.nextLine();
            stu.setAge(age);
            System.out.print("输入住址:");
            String dizhi = sc.nextLine();
            stu.setZhuzhi(dizhi);
            System.out.print("退出吗? y退出 任意键继续");
            String exit = sc.nextLine();
            list.add(stu);
            if (exit.equals("y")){
                return;
            }
        }
    }
    // 仅作ID存在查询
    public static int panduancunzai(ArrayList<Student> list,String id) {
        for (int i = 0; i < list.size(); i++) {
            if(list.get(i).getId().equals(id)){
                return i;
            }
        }
        return -1;
    }

    public static void shanchu(ArrayList<Student> list) {
        for (int i = 0; i < list.size(); i++) {
            list.get(i).xinxi();
//            System.out.printf("ID:%s\t姓名:%s\t年龄:%s\t地址:%s",list.get(i).getId(),list.get(i).getName(),list.get(i).getAge(),list.get(i).getZhuzhi());
        }
        System.out.print("请选择要删除的ID编号:");
        String id = sc.nextLine();
        int weizhi = panduancunzai(list,id);
        if(panduancunzai(list,id) == -1){
            System.out.println("该ID不存在!");
        }else {
            System.out.println("删除成功!");
            list.remove(weizhi);
        }
    }

    public static void chaxun(ArrayList<Student> list) {
        System.out.print("请输入要查询的数据:");
        String zhi = sc.nextLine();
        int weizhi = quanjucunzaichaxun(list,zhi);
        if (quanjucunzaichaxun(list,zhi) == -1) {
            System.out.println("未查询到该值");
        }else {
            list.get(weizhi).xinxi();
        }
    }
    // 全局数据或值存在查询
    public static int quanjucunzaichaxun(ArrayList<Student> list,String zhi){
        for (int i = 0; i < list.size(); i++) {
            if((list.get(i).getId().equals(zhi) || list.get(i).getName().equals(zhi)) || (list.get(i).getAge().equals(zhi) || list.get(i).getZhuzhi().equals(zhi))){
                return i;
            }
        }
        return -1;
    }
    public static void xiugai(ArrayList<Student> list) {
        System.out.print("请输入要修改的ID编号学生:");
        String xiugai = sc.nextLine();
        int weizhi = panduancunzai(list,xiugai);
        if(panduancunzai(list,xiugai) == -1){
            System.out.println("没有找到该ID编号的学生!");
        }else {
            System.out.print("输入新的ID:");
            list.get(weizhi).setId(sc.nextLine());
            System.out.print("输入新的姓名:");
            list.get(weizhi).setName(sc.nextLine());
            System.out.print("输入新的年龄:");
            list.get(weizhi).setAge(sc.nextLine());
            System.out.print("输入新的地址:");
            list.get(weizhi).setZhuzhi(sc.nextLine());
            System.out.println("录入成功!");
        }
    }
}