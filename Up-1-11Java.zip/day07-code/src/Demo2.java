import java.util.Arrays;

public class Demo2 {
    public static void main(String[] args) {
//        int[][] arr = new int[9][9];
//        while (true){
//            for (int i = 0; i < arr.length; i++) {
//                for (int j = 0; j < arr[i].length; j++) {
//                    arr[i][j] += 1;
//                    System.out.print(arr[i][j] + ",");
//                }
//                System.out.println();
//            }
//        }

//        int hang = 9;
//        int lie = 9;
//        int[] arr = new int[hang * lie];
//        int num = 1;
//        for (int i = 0; i < arr.length; i++) {
//            arr[i] += num;
//            num++;
//        }
//        // 假设访问4,4位置
//        int number = arr[hang * 4 + 4];
//
//        System.out.println(Arrays.toString(arr));
//        System.out.println(number);



    }
}