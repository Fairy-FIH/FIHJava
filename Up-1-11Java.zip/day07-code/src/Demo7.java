import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Demo7 {
    public static void main(String[] args) {
        // 1. 创建窗口 (JFrame)
        JFrame frame = new JFrame("商城营业额实时看板");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // 2. 准备数据（你的二维数组逻辑在这里）
        String[] columns = {"第一月", "第二月", "第三月"};
        Object[][] data = { {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0} };

        // 3. 创建表格模型并绑定
        DefaultTableModel model = new DefaultTableModel(data, columns);
        JTable table = new JTable(model);

        // 4. 重点：添加一个监听器，只要你改了表格里的数，它就自动算总和
        JLabel totalLabel = new JLabel("全年总营业额：0 万元", SwingConstants.CENTER);
        model.addTableModelListener(e -> {
            int sum = 0;
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    // 从表格里取数并求和
                    sum += Integer.parseInt(model.getValueAt(i, j).toString());
                }
            }
            totalLabel.setText("全年总营业额：" + sum + " 万元");
        });

        // 5. 把组件塞进窗口
        frame.add(new JScrollPane(table), BorderLayout.CENTER);
        frame.add(totalLabel, BorderLayout.SOUTH);

        // 6. 显示窗口
        frame.setVisible(true);
    }
}