//需求:
//把整数上的每一位都添加到数组当中
import java.util.Arrays;
import java.util.Scanner;
public class Test16 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int[] arr = new int[4];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextInt();
        }
        System.out.println(Arrays.toString(arr));
    }
}