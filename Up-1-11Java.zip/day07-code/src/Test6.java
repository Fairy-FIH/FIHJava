//        定义方法实现随机产生一个5位的验证码
//        验证码格式:
//        长度为5
//        前四位是大写字母或者小写字母
//        最后一位是数字

import java.util.Random;

public class Test6 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int yanZhenmaLength = 5;
        char yanZhenma = 0;
        for (int i = 1; i < yanZhenmaLength; i++) {
            yanZhenma += (char)(rand.nextInt(26));
        }
        System.out.println(yanZhenma);
    }

}