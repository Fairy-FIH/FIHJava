import java.util.Random;

public class Test24 {
    public static void main(String[] args) {
        Random rand = new Random();
        int[] arr = new int[]{2,588,888,1000,10000};
        for (int i = 0; i < arr.length; i++) {
            int a = rand.nextInt(arr.length);
            int temp = arr[a];
            arr[a] = arr[i];
            arr[i] = temp;
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
}