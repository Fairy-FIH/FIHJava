import java.util.Scanner;

public class PhoneTset {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Phone p = new Phone();
        Phone p1 = new Phone();
        System.out.println("输入1品牌");
        p.Pingpai = sc.nextLine();
        p.Jiage = 2399;
        System.out.println("输入2品牌");
        p1.Pingpai = sc.nextLine();
        p1.Jiage = 1999;
        System.out.println("手机品牌" + p.Pingpai + "手机价格" + p.Jiage);
        System.out.println("手机品牌" + p1.Pingpai + "手机价格" + p1.Jiage);
        System.out.println("选择给哪部手机操作");
        int sj = sc.nextInt();
        switch (sj) {
            case 1:
                pr();
                switch (caozuo()) {
                    case 1:
                        p.call();
                        break;
                    case 2:
                        p.Playgeme();
                        break;
                }
                break;
            case 2:
                pr();
                switch (caozuo()) {
                    case 1:
                        p.call();
                        break;
                    case 2:
                        p.Playgeme();
                        break;
                }
                break;
        }

    }
    public static int caozuo(){
        int caozuo = sc.nextInt();
        return caozuo;
    }

    public static void pr(){
        System.out.println("你要给该手机干什么" + "\n" + "1,打电话" + "\n" + "2,找他打游戏");
    }
}