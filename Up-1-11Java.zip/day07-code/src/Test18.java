import java.util.Arrays;
import java.util.Scanner;
// 需求:整数转数组

public class Test18 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int value = sc.nextInt();
        int Length = Logic(value);
        System.out.println(Length);
        int[] arr = new int[Length];
        int newLength = Length;
        int temp = newLength - 1;
        while(newLength != 0){
            arr[temp] = value % 10;
            value /= 10;
            temp--;
            newLength--;
        }
        System.out.println(Arrays.toString(arr));
    }
    public static int Logic(int a){
        if(a == 0){
            return 1;
        }
        int sum = 0;
        while(a != 0){
            a = a / 10;
            ++sum;
        }
        return sum;
    }
}