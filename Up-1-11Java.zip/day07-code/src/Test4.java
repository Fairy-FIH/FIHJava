public class Test4 {
    public static void main(String[] args) {
//        1、判断101-200之间有多少个素数，并输出所有素数。
//        int count = 0;
//        for (int i = 101; i <= 200; i++) {
//            boolean a = true;
//            for (int j = 2; j < i - 1; j++) {
//                if(i % j == 0){
//                    a = false;
//                    break;
//                }
//            }
//            if(a){
//                System.out.println(i);
//                count++;
//            }
//        }
//        System.out.println(count);

        int count = 0;
        for (int i = 101; i <= 200; i++) {
            int hjm = 0;
            for (int j = 1; j <= i; j++) {
                if (i % j == 0) {
                    hjm++;
                }
            }
            if (hjm == 2) {
                System.out.println(i);
                count++;
            }
        }
        System.out.println(count);
    }
}