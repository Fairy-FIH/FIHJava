/*机票价格按照淡季旺季、头等舱和经济舱收费、输入机票原价、月份和头等舱或经济舱。
按照如下规则计算机票价格:旺季(5-10月)头等舱9折，经济舱8.5折，淡季(11月到来年4月)头等舱7折，经济舱6.5折。*/

import java.util.Scanner;

public class Test2 {
    static Scanner sc = new Scanner(System.in);

    // 初始化全局输入类库
    public static void main(String[] args) {
        text();
        // 调用text程序!
        sc.close();
        // 关闭输入库,释放内存
    }

    public static void text() {
        System.out.println("请输入机票价格");
        double jiage = sc.nextDouble();
        System.out.println("请输入月份");
        int Riqi = sc.nextInt();
        if (!riqipanduan(Riqi)) {
            // 判断日期范围,超出或没有到范围退出程序
            System.out.println("日期不对,程序已退出");
            return;
        }
        while (true) {
            // 使用while死循环提供用户试错次数
            System.out.println("请选择头等舱或者经济舱");
            System.out.println("1,头等舱" + "\t" + "2,经济舱");
            int xuanze = sc.nextInt();
            if (!cangpanduan(xuanze)) {
                System.out.println();
                System.out.println("舱位不匹配,请重新选择");
            } else {
                String str = String.format("%.2f", panduan(xuanze, Riqi, jiage));
                System.out.println("价格为:" + str);
                break;
            }
        }
    }

    public static boolean riqipanduan(int riqi) {
        // 该方法负责日期的判断逻辑,如果为不正常日期范围,返回flase值,如果正常,返回ture
        if (riqi > 12 || riqi < 1) {
            return false;
        }
        return true;
    }

    public static boolean cangpanduan(int a) {
        // 该方法负责舱位的判断逻辑,如果为不正常舱位范围,返回flase值,如果正常,返回ture
        if (a < 1 || a > 2) {
            return false;
        }
        return true;
    }

    public static double panduan(int xaunze, int riqi, double jiage) {
        // 程序主逻辑判断方法,三个值,舱位,日期(月份),价格,使用hjm返回计算价格
        double hjm = 0;
        if (xaunze == 1) {
            if (riqi >= 11 || riqi <= 4) {
                hjm = (0.7 * jiage);
            } else {
                hjm = (0.9 * jiage);
            }
        } else {
            if (riqi >= 11 || riqi <= 4) {
                hjm = (0.65 * jiage);
            } else {
                hjm = (0.85 * jiage);
            }
        }
        return hjm;
    }
}