/*某商城每个季度的营业额如下:单位(万元)
第一季度:22,66,44
第二季度:77,33,88
第三季度:25,45,65
第四季度:11,66,99
要求计算出每个季度的总营业额和全年的总营业额*/


public class Demo5 {
    public static void main(String[] args) {
        Demo6 bbj =  new Demo6();
        int[][] no1 = new int[][]{
                {22,66,44},
                {77,33,88},
                {25,45,65},
                {11,66,99}
        };
        for(int i = 0;i < no1.length;i++){
            for(int j = 0;j < no1[i].length;j++){
                System.out.print(no1[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("各季度总营业额为:");
        System.out.println("第一季度" + fanhui(no1,0,1) + "万元");
        System.out.println("第二季度" + fanhui(no1,1,2) + "万元");
        System.out.println("第三季度" + fanhui(no1,2,3) + "万元");
        System.out.println("第四季度" + fanhui(no1,3,4) + "万元");
        System.out.println("全年总营业额为:");
        System.out.println(zong(no1) + "万元");

    }
    public static int fanhui(int[][] arr,int a,int b){
        int sum = 0;
        for(int i = a;i < b;i++){
            for(int j = 0;j < arr[i].length;j++){
                sum = sum + arr[i][j];
            }
        }
        return sum;
    }
    public static int zong(int[][] arr){
        int sum = 0;
        for(int i = 0;i < arr.length;i++){
            for(int j = 0;j < arr[i].length;j++){
                sum += arr[i][j];
            }
        }
        return sum;
    }
}