import java.util.Random;
// 调用随机数生成器库

public class Test26 {
    static Random rand = new Random();
    // 全局初始化随机数生成器
    public static void main(String[] args) {
        int[] arr = new int[]{1,41,54,23,64,21,89,71};
        // 定义数组arr存原始值
        int[] newarr = new int[5];
        // 定义新数组存长度为5的值
        for (int i = 0; i < newarr.length;) {
            // 循环遍历新数组,准确来说开始添加数据给新数组,此处不自增
            int x = rand.nextInt(arr.length);
            // 定义x为每次的随机数,随机范围为arr原数组的长度也就是(0~8)
            boolean flag = panduan(newarr,arr[x]);
            // 调用panduan方法给flag,pandaun方法在本次的判断实参为(新数组newarr和原始数组arr[随机的数x])
            if (flag) {
                // 如果不为flag也就是判断为ture时
                newarr[i] = arr[x];
                // 将新数组的当前索引替换为新随机数(arr数组里的值)
                i++;
                // 执行一次自增
            }
        }

        for(int hjm : newarr){
            System.out.print(hjm + " ");
        }

    }
    public static boolean panduan(int[] arr,int b){
        // panduan方法(形参是一个数组和一个整数值)
        for(int i=0;i<arr.length;i++){
            // 循环遍历数组
            if(arr[i]==b){
                // 如果数组的值等于整数的话
                return false;
                // 返回true给panduan方法
            }
        }
        return true;
        // 默认返回flase给方法
    }
}