//需求:
//把一个数组中的元素复制到另一个新数组中去。

public class Test9 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5};
        int[] arr2 = new int[arr.length];
        for (int i = 0; i < arr2.length; i++) {
//            int temp = arr[i];
//            arr2[i] = temp;
            arr2[i] = arr[i];
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
        }
        System.out.println();
        for (int i = 0; i < arr2.length; i++) {
            System.out.print(arr2[i]);
        }
        System.out.println();
        System.out.println(arr);
        System.out.println(arr2);
    }

}