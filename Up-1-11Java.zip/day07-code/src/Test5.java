import java.util.Random;

public class Test5 {
    static Random rand = new Random();
    public static void main(String[] args) {
//        定义方法实现随机产生一个5位的验证码
//        验证码格式:
//        长度为5
//        前四位是大写字母或者小写字母
//        最后一位是数字
        char[] num = yanZhenma();
        int zuiHou = rand.nextInt(10);
        String zuiZhong = new String(num) + zuiHou;
        System.out.println(zuiZhong);
    }
    public static char[] yanZhenma(){
        char[] arr = new char[4];
        for(int i = 0;i < arr.length;i++){
            int jueDing = rand.nextInt(0,2);
            char hjm;
            if(jueDing == 0){
                hjm = (char)('a' + (rand.nextInt(26)));
            }else {
                hjm = (char)('A' + (rand.nextInt(26)));
            }
            arr[i] = hjm ;
        }
        return arr;
    }
}