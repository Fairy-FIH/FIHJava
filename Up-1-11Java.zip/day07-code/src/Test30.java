import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Test30 {
    static Scanner sc = new Scanner(System.in);
    static Random rand = new Random();
    public static void main(String[] args){

        print();
        sc.close();
    }
    public static void print(){
        int[] shurured = new int[redarr().length];
        int[] shurublue = new int[bluearr().length];

        System.out.println("当前猜测红球");
        for(int i = 0; i < shurured.length;){
            int shuru = sc.nextInt();
            if (shuru > 33 || shuru < 1){
                System.out.println("非法范围");
            } else if (panduan(shurured,shuru,i)) {
                System.out.println("号码重复");
            } else {
                shurured[i] = shuru;
                System.out.println("当前" + (i + 1) + "已录入");
                i++;
            }
        }
        System.out.println(Arrays.toString(shurured));

        System.out.println("当前猜测蓝球");
        while(true){
            int shuru = sc.nextInt();
            if (shuru > 16 || shuru < 1){
                System.out.println("非法范围");
            }else {
                shurublue[0] = shuru;
                System.out.println("当前蓝球已录入");
                break;
            }
        }

        System.out.println(Arrays.toString(shurublue));

        System.out.println("开始摇色");
        int[] rad = redarr();
        int[] blue = bluearr();
        System.out.println(Arrays.toString(rad));
        System.out.println(Arrays.toString(blue));

        System.out.println("开始判断");
        System.out.println();
        int rsount = 0;
        int bcount = 0;
        for(int i = 0; i < rad.length;i++){
            for(int j = 0; j < shurured.length;j++){
                if(shurured[j] == rad[i]){
                    rsount++;
                    break;
                }
            }
//            if(flag){
//                System.out.println(rad[i] + "猜中啦!(红色)");
//            }
        }
        System.out.println("红色共猜中" + rsount);

        if(shurublue[0] == blue[0]){
            bcount++;
        }
        System.out.println("蓝色共猜中" + bcount);
        System.out.println();
        System.out.println("共猜中" + (rsount + bcount) + "个");

        System.out.println();
        int jiang = jiangjin(rsount, bcount);
        if (jiang == 1 || jiang == 2 || jiang == 3){
            System.out.println("中5元");
        } else if (jiang == 4 || jiang == 5) {
            System.out.println("中10元");
        }else if (jiang == 6 || jiang == 7){
            System.out.println("中200元");
        }else if (jiang == 8){
            System.out.println("中3000元");
        }else if (jiang == 9 ){
            System.out.println("中500万元");
        }else if (jiang == 10){
            System.out.println("中1000万元");
        }else {
            System.out.println("恭喜你,啥都没中");
        }

    }
    public static int jiangjin(int red,int blue){
        int a = 0;
        if(red == 1 && blue == 1){
            a =  2;
        }else if(red == 0 && blue == 1){
            a =  1;
        }
        else if(red == 2 && blue == 1){
            a = 3;
        }else if(red == 3 && blue == 1){
            a = 4;
        }
        else if(red == 4 && blue == 0){
            a = 5;
        }else if(red == 4 && blue == 1){
            a = 6;
        }
        else if(red == 5 && blue == 0){
            a = 7;
        }else if(red == 5 && blue == 1){
            a = 8;
        }else if(red == 6 && blue == 0){
            a = 9;
        }
        else if(red == 6 && blue == 1){
            a = 10;
        }
        return a;
    }

    public static int[] redarr(){
        int[] red = new int[6];
        for(int i=0; i < red.length;){
            int a = rand.nextInt(1,34);
            boolean flag = panduan(red,a,i);
            if (!flag){
                red[i] = a;
                i++;
            }
        }
        return red;
    }
    public static boolean panduan(int[] arr,int a,int l){
        for(int i=0; i < l; i++){
            if(arr[i] == a){
                return true;
            }
        }
        return false;
    }
    public static int[] bluearr(){
        return new int[]{rand.nextInt(1,17)};
    }
}