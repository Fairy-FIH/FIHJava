import java.util.Arrays;
import java.util.Random;
public class Test23 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = arr();
        int[] arr2 = new int[arr.length];
        for (int i = 0; i < arr.length;) {
            int a = rand.nextInt(arr.length);
            int jiang = arr[a];
            boolean pd = panduan(arr2,jiang);
            if(!pd){
                arr2[i] = jiang;
                i++;
            }
        }
        for(int a : arr2){
            System.out.println(a);
        }
    }
    public static int[] arr(){
        return new int[]{2,588,888,1000,10000};
    }
    public static boolean panduan(int[] arr, int n){
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] == n){
                return true;
            }
        }
        return false;
    }
}