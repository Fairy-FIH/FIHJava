import java.util.Arrays;
import java.util.Random;

public class Test36 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = new int[6];
        for (int i = 0; i < arr.length;) {
            int a = rand.nextInt(1,34);
            boolean flag = pd(arr,a,i);
            if (!flag) {
                arr[i] = a;
                i++;
            }
        }


        System.out.println(Arrays.toString(arr));
    }
    public static boolean pd(int[] arr,int a,int b){
        for (int i = 0; i < b; i++) {
            if (arr[i] == a){
                return true;
            }
        }
        return false;
    }
}