import java.util.Arrays;
import java.util.Scanner;

public class Test17 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        print();
    }
    public static int cdjs(int a) {
        if (a == 0) {
            return 1;
        }
        a = Math.abs(a);
        int count = 0;
        while (a != 0) {
            a = a / 10;
            ++count;
        }
        return count;
    }
    public static void print() {
        System.out.println("输入整数");
        int a = sc.nextInt();
        int original = Math.abs(a);
        int digitCount = cdjs(a);
        int[] digitArray = new int[digitCount];
        int index = digitCount - 1;
        int temp = original;
        while (temp != 0) {
            int lastDigit = temp % 10;
            digitArray[index] = lastDigit;
            temp = temp / 10;
            index--;
        }
        if (original == 0) {
            digitArray[0] = 0;
        }
        System.out.println("整数的每一位存入数组结果：" + Arrays.toString(digitArray));
    }
}