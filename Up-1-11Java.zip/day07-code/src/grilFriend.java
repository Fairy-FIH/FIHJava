/** 编写女朋友类，创建女朋友类的对象
 * 给女朋友的属性赋值并调用女朋友类中的方法
 自己思考，女朋友类中有哪些属性，有哪些行为? **/

import java.util.Scanner;

public class grilFriend {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Gril gril = new Gril();
        gril.setName(sc.next());
        gril.setAge(sc.nextInt());
        gril.setHeight(sc.nextInt());
        System.out.println("名字" + gril.getName());
        System.out.println("年龄" + gril.getAge());
        System.out.println("海拔" + gril.getHeight());
        System.out.println("好感度" + gril.Love);
        sc.close();
    }
}