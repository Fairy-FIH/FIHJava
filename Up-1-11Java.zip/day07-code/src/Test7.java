import java.util.Random;

//        定义方法实现随机产生一个5位的验证码
//        验证码格式:
//        长度为5
//        前四位是大写字母或者小写字母
//        最后一位是数字

public class Test7 {
    static Random rand = new Random();
    public static void main(String[] args) {
        char[] chararr = new char[52];
        for (int i = 0; i < chararr.length; i++) {
            if(i <= 25){
                chararr[i] = (char) (97 + i);
            }else{
                chararr[i] = (char) (65 + i - 26);
            }
        }
        String num = "";
        for (int i = 0; i < 4; i++) {
            num += chararr[rand.nextInt(chararr.length)];
        }
        int sumber = rand.nextInt(10);
        num += sumber;
        System.out.println(num);

    }
}