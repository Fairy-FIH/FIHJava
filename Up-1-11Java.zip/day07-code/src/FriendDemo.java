//        System.out.println("请输入姓名");
//        String name = sc.nextLine();
//        System.out.println("请输入年龄");
//        int age = sc.nextInt();
//        Friend f1 = new Friend();
//        f1.Setname(name);
//        f1.Setage(age);
//        System.out.println("姓名" + f1.Getname() + "年龄" + f1.Getage());
//        sc.close();

import java.util.Scanner;

public class FriendDemo {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        Friend[] f = f();
        for (int i = 0; i < f.length; i++) {
            System.out.println("第" + (i + 1) + "个人信息为: 姓名:" + f[i].Getname() + "年龄: " + f[i].Getage());
        }
        sc.close();
    }
    public static Friend[] f(){
        Friend[] f = new Friend[2];
        for (int i = 0; i < f.length; i++) {
            System.out.println("请输入第" + (i + 1) + "个人信息");
            f[i] = new Friend();
            System.out.println("请输入名字");
            String name = sc.next();
            f[i].Setname(name);
            System.out.println("请输入年龄");
            int age = sc.nextInt();
            f[i].Setage(age);
        }
        return f;
    }
}




