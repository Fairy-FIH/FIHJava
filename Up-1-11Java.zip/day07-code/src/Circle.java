public class Circle {
    private double banjin;
    private double zhijin;

    public Circle(double banjin) {
        this.banjin = banjin;
    }
    public Circle() {
    }
    public double getBanjin() {
        return banjin;
    }
    public void setBanjin(double banjin) {
        this.banjin = banjin;
    }
    public double getZhijin(){
        return this.banjin * 2;
    }
}