import java.util.Arrays;
import java.util.Scanner;
public class Test14 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println(Arrays.toString(arr()));
    }
    public static int[] arr(){
        int[] arr = new int[4];
        System.out.println("请输入密钥");
        for (int i = 0; i < arr.length; i++) {
            int shuru = sc.nextInt();
            arr[i] = shuru;
        }
        for (int i = 0; i < arr.length; i++) {
            arr[i] = arr[i] + 5;
            arr[i] = arr[i] % 10;
        }
        int[] arr2 = new int[arr.length];
        for (int i = 0; i < arr2.length; i++) {
            arr2[i] = arr[arr.length - i - 1];
        }
        return arr2;
    }
}