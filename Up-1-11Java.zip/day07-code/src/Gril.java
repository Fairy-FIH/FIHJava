public class Gril {
    private String name;
    private int age;
    private int height;
    public int Love = 100;

    public Gril(String name, int age, int height) {
        this.name = name;
        this.age = age;
        this.height = height;
    }

    public Gril() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setHeight(int height) {
        this.height = height;
        if (height > 170) {
            Love += 10;
        } else {
            Love += 5;
        }
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public int getHeight() {
        return height;
    }
}