//        定义方法实现随机产生一个5位的验证码
//        验证码格式:
//        长度为5
//        前四位是大写字母或者小写字母
//        最后一位是数字

import java.util.Arrays;
import java.util.Random;

public class Test8 {
    static Random rand = new Random();
    public static void main(String[] args) {
        shuchu();
    }
    public static void shuchu(){
        String str = new String(shuzu()) + shuzi();
        System.out.println("验证码为");
        System.out.println(str);
    }
    public static char[] shuzu(){
        char[] yanzhenma = new char[4];
        for(int i = 0; i < yanzhenma.length; i++){
            int suiji = rand.nextInt(2);
            if(suiji == 0){
                yanzhenma[i] = (char)('a' + rand.nextInt(26));
            }else {
                yanzhenma[i] = (char) ('A' + rand.nextInt(26));
            }
        }
        return yanzhenma;
    }
    public static int shuzi(){
        return rand.nextInt(10);
    }
}