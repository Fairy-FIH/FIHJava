//        定义方法实现随机产生一个5位的验证码
//        验证码格式:
//        长度为5
//        前四位是大写字母或者小写字母
//        最后一位是数字
import java.util.Random;

public class Test1{
    static Random rand = new Random();
    // 全局随机数类库;
    public static void main(String[] args){
        // 程序开始执行;
        String str = new String(shuzu()) + shuzi();
        // 定义新字符串str,值为shuzu方法,也就是返回的4个随机数值+随即数字
        System.out.print(str);
        // 打印str数组,生成5个(前4个为大小写数字,后一个为随机数字)验证码
    }
    public static char[] shuzu(){
        // 创建字符数组
        char[] arr = new char[4];
        // 字符数组长度为4
        for(int i = 0;i < arr.length;i++){
            // 遍历数组
            int suiji = rand.nextInt(2);
            // 设置一个随机数0,1的值
            if(suiji == 0){
                // 如果等于0.执行小写字母随机
                arr[i] = (char)('a' + rand.nextInt(26));
            }else{
                // 如果不等于0,也就剩1,执行大写随机
                arr[i] = (char)('A' + rand.nextInt(26));
            }
        }
        // 返回四个随机数给shuzu方法
        return arr;
    }
    public static int shuzi(){
        // 定义一个生成0~9的随机数方法
        return rand.nextInt(10);
    }
}