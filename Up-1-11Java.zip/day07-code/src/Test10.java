//需求:
//在唱歌比赛中，有6名评委给选手打分，分数范围是[0-1001之间的整数。选手的最后得分为:去掉最高分、最低分后的4个评委的平均分，请完成上述过程并计算出选手的得分。


import java.util.Random;

public class Test10 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = new int[6];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rand.nextInt(101);
        }
        System.out.print("随机数有:");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(" " + arr[i] + " ");
        }
        System.out.println();
        System.out.println();
        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if(arr[i] > max){
                max = arr[i];
            }
        }
        System.out.println("最高分" + max);
        int min = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if(arr[i] < min){
                min = arr[i];
            }
        }
        System.out.println("最低分为" + min);
        int svg = 0;
        for (int i = 0; i < arr.length; i++) {
            svg += arr[i];
        }
        svg = (svg - (min + max)) / 4;
        System.out.println();
        System.out.println("平均分为" + svg);
    }
}