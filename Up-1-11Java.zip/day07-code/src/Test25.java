import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Test25 {
    static Random rand = new Random();
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) throws InterruptedException {
        int[] caice = new int[6];
        int[] caice2 = new int[1];
        System.out.println("请输入要猜测的红球数字(范围1~33)");
        for (int i = 0; i < caice.length; i++) {
            while(true){
                System.out.println("第" + (i + 1) + "位数字");
                int sr = sc.nextInt();
                if (sr > 33 || sr < 1){
                    System.out.println("===非法字符===");
                }else {
                    caice[i] = sr;
                    break;
                }
            }
        }
        System.out.println();
        while (true){
            System.out.println("请输入要猜测的蓝球数字(范围1~16)");
            int sr = sc.nextInt();
            if (sr > 16 || sr < 1){
                System.out.println();
                System.out.println("===非法字符===");
            }else {
                caice2[0] = sr;
                break;
            }
        }
        System.out.println();
        System.out.println("生成中奖号码中");
        int[] radjiangchi = new int[6];
        int[] bluejiangchi = new int[1];
        for(int i = 0;i < radjiangchi.length;){
            int sjs = rand.nextInt(1,34);
            boolean flag = shengchenpanduan(radjiangchi,sjs,i);
            if(!flag){
                radjiangchi[i] = sjs;
                System.out.println("红球" + (i +1) + "：" + sjs);
                Thread.sleep(500);
                i++;
            }
        }
        int jsj = rand.nextInt(1,17);
        bluejiangchi[0] = jsj;
        System.out.println("蓝球：" + bluejiangchi[0]);
        Thread.sleep(300);
        System.out.println("生成的中奖号码为");
        Thread.sleep(300);
        System.out.println(Arrays.toString(radjiangchi));
        Thread.sleep(300);
        System.out.println(Arrays.toString(bluejiangchi));
        Thread.sleep(300);
        System.out.println("你猜测的红球数字为");
        System.out.println(Arrays.toString(caice));
        Thread.sleep(300);
        System.out.println("你猜测的蓝球数字为");
        System.out.println(Arrays.toString(caice2));
        System.out.println();
        Thread.sleep(1000);
        int count1 = 0;
        System.out.println("===红球比对===");
        for (int i = 0; i < radjiangchi.length; i++) {
            boolean flag = false;
            for (int j = 0; j < caice.length; j++) {
                if(radjiangchi[i] == caice[j]){
                    flag = true;
                    count1++;
                    break;
                }
            }
            if(flag){
                System.out.println(radjiangchi[i] + "猜中啦");
            }else {
                System.out.println(radjiangchi[i] + "该数字未猜中");
            }
        }
        Thread.sleep(1000);
        int count2 = 0;
        System.out.println();
        System.out.println("===蓝球比对===");
        if (caice2[0] == bluejiangchi[0]){
            System.out.println("蓝球猜中了");
            count2++;
        }
        else {
            System.out.println("蓝球未猜中");
        }
        int count = count1 + count2;
        System.out.println();
        System.out.println("共猜中" + count + "个," + "其中,红球为" + count1 + "个,蓝球为" + count2 + "个");
        sc.close();
    }
    public static boolean shengchenpanduan(int[] a,int b,int l){
        for(int i = 0;i < l;i++){
            if(a[i] == b){
                return true;
            }
        }
        return false;
    }

}