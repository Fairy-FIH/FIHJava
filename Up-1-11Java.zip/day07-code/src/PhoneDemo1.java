public class PhoneDemo1 {
    public static void main(String[] args) {
        Phone[] arr = new Phone[3];
        arr[0] = new Phone();
        arr[1] = new Phone();
        arr[2] = new Phone();
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
}