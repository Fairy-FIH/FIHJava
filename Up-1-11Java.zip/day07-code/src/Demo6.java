import java.util.Scanner;

public class Demo6 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        int[][] arr = arr();
        for(int i = 0; i < arr.length; i++) {
            System.out.println("第" + (i  + 1) + "季度营业总额为:" + yinye(arr[i]));
        }
        System.out.println();
        int sum = 0;
        for(int i = 0; i < arr.length; i++) {
            sum += yinye(arr[i]);
        }
        System.out.println("总营业额为:" + sum);
        sc.close();
    }
    public static int[][] arr(){
        System.out.println("输入共多少季度");
        int jidu = sc.nextInt();
        System.out.println("输入共多少月");
        int yue = sc.nextInt();
        int[][] arr = new int[jidu][yue];
        System.out.println("================");
        for(int i = 0; i < arr.length; i++) {
            for(int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println("================");
        for (int i = 0; i < arr.length; i++) {
            System.out.println("第" + (i + 1) +"季度营业额:");
            for (int j = 0; j < arr[i].length;j++) {
                System.out.print("请输入:");
                int input = sc.nextInt();
                arr[i][j] = input;
            }
        }
        return arr;
    }
    public static int yinye(int[] arr){
        int sum = 0;
        for(int hjm : arr){
            sum += hjm;
        }
        return sum;
    }
}