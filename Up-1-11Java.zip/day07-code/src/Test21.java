import java.util.Random;

public class Test21 {
    static Random rand = new Random();
    // 初始化随机数
    public static void main(String[] args) {
        int[] arr = arr();
        // 调用方法arr();
        System.out.println("你中奖了");
        for(int i = arr.length -1;i > 0;i--){
            // 洗牌算法从最大索引(当前4),自减遍历.直到为1时(此处i > 0)
            int a = rand.nextInt(i + 1);
            // 创建随机数a,每次随机种子为i + 1;(当前4 + 1,即5)
            int temp = arr[i];
            // 创建临时存储,存储arr数组的i值,当前为arr[4] ,即10000
            arr[i] = arr[a];
            // 将arr[4]索引位的值修改为arr[a随机到的数字]
            arr[a] = temp;
            // 将arr[a随机到的数字]赋值为10000
        }
        for(int num : arr){
            System.out.println(num);
        }
    }
    public static int[] arr(){
        return new int[]{2,588,888,1000,10000};
    }
}