import java.util.Arrays;

public class Test31 {
    public static void main(String[] args) {
//        int[][] arr = {{11,22},{33,44}};
////        for(int i = 0;i < arr.length;i++){
////            for(int j = 0;j < arr.length;j++){
////                System.out.print(arr[i][j]);
////            }
////            System.out.println();
////        }
//        int[][][] arr2 = {{{11,22},{33,44},{55,66}}};
        int[][][][] arr3 = {{{{11,22},{33,44},{55,66},{77,88}}}};
//        int[] arr = {11,22};
//        int[] arr2 = {33,44};
//        int[] arr3 = {55,66};
//        int[] arr4 = {77,88};
//        int[][] arr5 = {arr,arr2,arr3,arr4};
//        for (int i = 0; i < arr5.length; i++) {
//            for (int j = 0; j < arr5[i].length; j++) {
//                System.out.print(arr5[2][1] + " ");
//            }
//            System.out.println();
//        }
        System.out.print(arr3[0][0][3][0] + " ");
    }

}