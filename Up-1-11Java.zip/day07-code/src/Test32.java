import java.util.Arrays;
import java.util.Random;

public class Test32 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] rad = new int[6];
        int[] blue = new int[6];

        int count = 0;
        // 计数器,初始值为0
        while (count < rad.length) {
            // 循环至rad数组长度(检查所有元素)
            int shengcheng = rand.nextInt(1,34);
            // 定义随机数范围
            boolean flag = true;
            // 假设一开始数组没有这个元素
            for (int i = 0; i < count; i++) {
                //遍历检查当前元素
                if (rad[i] == shengcheng) {
                    // 如果当前rad数组有这个随机数
                    flag = false;
                    //返回false
                    break;
                    // 结束当前循环
                }
            }
            if (flag) {
                // 检查到没有这个元素,将这个元素给数组
                rad[count] = shengcheng;
                // 开始添加元素
                count++;
                // 计数器(索引+1)
            }
        }
        System.out.println(Arrays.toString(rad));

        for (int i = 0; i < blue.length;) {
            int shengcheng = rand.nextInt(1,34);
            boolean flag = pd(blue,shengcheng,i);
            if(!flag){
                blue[i] = shengcheng;
                i++;
            }
        }
        System.out.println(Arrays.toString(blue));
    }
    public static boolean pd(int[] arr,int a,int b){
        for (int i = 0; i < b; i++) {
            if(arr[i] == a){
                return true;
            }
        }
        return false;
    }
}