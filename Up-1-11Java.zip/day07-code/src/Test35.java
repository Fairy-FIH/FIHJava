import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;

public class Test35 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = new int[6];
        int count = 0;
//        while(count < arr.length){
//            int a = rand.nextInt(1,34);
//            boolean flag = false;
//            for(int i = 0;i < count;i++){
//                if(arr[i] == a){
//                    flag = true;
//                    break;
//                }
//            }
//            if(!flag){
//                arr[count] = a;
//                count++;
//            }
//        }
//
        do {
            int a = rand.nextInt(1,34);
            boolean flag = false;
            for(int i = 0;i < count;i++){
                if(arr[i] == a){
                    flag = true;
                    break;
                }
            }
            if(!flag){
                arr[count] = a;
                count++;
            }
        }while(count < arr.length);

        System.out.println(Arrays.toString(arr));
    }
}