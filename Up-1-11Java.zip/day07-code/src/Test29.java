import java.util.Arrays;
import java.util.Random;

public class Test29 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = new int[]{1,54,66,23,60,97,21,84,75,100,91};
        int[] arr2 = new int[5];
        for (int i = 0; i < arr2.length;) {
            int a = rand.nextInt(arr.length);
            boolean flag = panduan(arr2,arr[a]);
            if (!flag) {
                arr2[i] = arr[a];
                i++;
            }
        }
        for (int i = 0; i < arr2.length; i++) {
            for (int j = 0; j < arr2.length - i - 1; j++) {
                if (arr2[j] > arr2[j + 1]) {
                    int temp = arr2[j];
                    arr2[j] = arr2[j + 1];
                    arr2[j + 1] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(arr2));
    }
    public static boolean panduan(int[] arr,int a){
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] == a){
                return true;
            }
        }
        return false;
    }

}