import java.util.Arrays;

public class Test15 {
    public static void main(String[] args) {
        fangfa1();
        System.out.println();
        fangfa2();
    }

    public static void fangfa2() {
        int[] a = new int[]{1,7,5,2};
        System.out.println("原数组:" + Arrays.toString(a));
        for(int i = 0,j = a.length - 1;i < j;i++,j--){
            int temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
        System.out.println("倒序后:" + Arrays.toString(a));
    }

    public static void fangfa1() {
        int[] a = new int[]{1,7,5,2};
        System.out.println("原数组:" + Arrays.toString(a));
        int[] b = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            b[i] = a[a.length - 1 - i];
        }
        System.out.println("倒序后:" + Arrays.toString(b));
    }
}