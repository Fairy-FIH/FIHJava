//需求:
//在唱歌比赛中，有6名评委给选手打分，分数范围是[0-1001之间的整数。选手的最后得分为:去掉最高分、最低分后的4个评委的平均分，请完成上述过程并计算出选手的得分。

import java.util.Scanner;

public class Test11 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
       int[] arr = fenshu();
       int max = arr[0];
       int min = arr[0];
       int svg = 0;
       for (int i = 1; i < arr.length; i++) {
           if (arr[i] > max) {
               max = arr[i];
           }else if (arr[i] < min) {
               min = arr[i];
           }
       }
       for (int i = 0; i < arr.length; i++) {
           svg += arr[i];
       }
       svg = (svg - (max + min)) / 4;
       System.out.println();
       System.out.println("得分为" + svg);
    }
    public static int[] fenshu(){
        int count = 0;
        int[] arr = new int[6];
        do {
            System.out.println("输入成绩");
            arr[count] = sc.nextInt();
            count++;
        }while (count < arr.length);
        return arr;
    }
}