//需求:
//一个大V直播抽奖，奖品是现金红包，分别有{2,588,888,1000,10000}五个奖金。
// 请使用代码模拟抽奖打印出每个奖项，奖项的出现顺序要随机且不重复。打印效果如下:(随机顺序，不一定是下面的顺序)

import java.util.Random;

public class Test20 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = arr();
        System.out.println("你中奖了");
        for(int i = arr.length - 1;i > 0 ;i--){
            int a = rand.nextInt(i + 1);
            int temp = arr[i];
            arr[i] = arr[a];
            arr[a] = temp;
        }
        for(int i = 0;i < arr.length;i++){
            System.out.println(arr[i] + "元");
        }

    }
    public static int[] arr(){
        return new int[] {2,588,888,1000,10000};
    }
}