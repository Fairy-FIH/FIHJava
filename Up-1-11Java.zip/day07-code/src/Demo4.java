public class Demo4 {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("===游戏加载中===");
        for (int i = 0; i <= 100; i++) {
            System.out.print("\r当前进度" + i + "%");
            if (i == 99) {
                Thread.sleep(1000);
            }
            Thread.sleep(100);
        }
    }
}