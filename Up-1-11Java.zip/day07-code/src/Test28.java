import java.util.Random;

public class Test28 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] luckNums = new int[]{5, 12, 18, 23, 30, 36, 42, 50, 66, 88};
        int[] selectedNums = new int[7];
        for (int i = 0; i < selectedNums.length;) {
            int sjs = rand.nextInt(luckNums.length);
            boolean flag = pd(selectedNums,luckNums[sjs]);
            if (!flag){
                selectedNums[i] = luckNums[sjs];
                i++;
            }
        }

        for(int i=0;i < selectedNums.length - 1;i++){
            for(int j=0;j < selectedNums.length - 1 -i;j++){
                if(selectedNums[j] > selectedNums[j+1]){
                    int temp = selectedNums[j];
                    selectedNums[j] = selectedNums[j+1];
                    selectedNums[j+1] = temp;
                }
            }
        }
        System.out.print("恭喜你抽到的幸运数字：");
        for (int i = 0; i < selectedNums.length; i++) {
            System.out.print(selectedNums[i] + " ");
        }
    }
    public static boolean pd(int[] arr,int a){
        for (int i = 0; i < arr.length; i++) {
            if(arr[i]==a){
                return true;
            }
        }
        return false;
    }
}