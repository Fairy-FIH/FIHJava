import java.util.Arrays;
import java.util.Scanner;

public class Test19 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        while (true) {
            System.out.println("1.加密 / 2.解密");
            int xuanze = sc.nextInt();
            if (xuanze < 1 || xuanze > 2) {
                System.out.println("=============");
                System.out.println("!请输入正确范围!");
            }else {
                switch (xuanze) {
                    case 1:
                        String s = "";
                        System.out.println("输入加密数字");
                        int[] arr = jiami();
                        for (int i = 0; i < arr.length; i++) {
                            s += arr[i];
                        }
                        System.out.println(s);
                        break;
                    case 2:
                        System.out.println("输入解密数字");
                        System.out.println(Arrays.toString(jiemii()));
                        break;
                }
                break;
            }
        }
        sc.close();
    }
    public static int[] jiemii(){
        int[] arrs = huoquLength();
        for (int i = 0,j = arrs.length - 1; i < j; i++,j--) {
            int temp = arrs[i];
            arrs[i] = arrs[j];
            arrs[j] = temp;
        }
        for (int i = 0; i < arrs.length; i++) {
            int temp = ((arrs[i] - 5) + 10) % 10;
            arrs[i] = Math.abs(temp);

        }
        return arrs;
    }
    public static int[] jiami() {
        int[] arrs = huoquLength();
        for (int i = 0; i < arrs.length; i++) {
            int temp = (arrs[i] + 5) % 10;
            arrs[i] = temp;
        }
        for (int i = 0, j = arrs.length - 1; i < j; i++, j--) {
            int temp = arrs[i];
            arrs[i] = arrs[j];
            arrs[j] = temp;
        }
        return arrs;
    }
    public static int[] huoquLength() {
        int number = sc.nextInt();
        int Length = Logic(number);
        int[] arr = new int[Length];
        int lmax = Length - 1;
        while (number != 0) {
            arr[lmax] = number % 10;
            number /= 10;
            lmax--;
        }
        return arr;
    }
    public static int Logic(int a) {
        if (a == 0) {
            return 1;
        }
        int sount = 0;
        while (a != 0) {
            a = a / 10;
            ++sount;
        }
        return sount;
    }
}