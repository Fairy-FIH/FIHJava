import java.util.Scanner;
public class Test13 {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        System.out.println("请输入密钥");
        int mima = sc.nextInt();
        int ge = mima % 10;
        int shi = (mima / 10) % 10;
        int bai = (mima / 100) % 10;
        int qian = (mima / 1000) % 10;
        int hjm1 = (ge += 5) % 10;
        int hjm2 = (shi += 5) % 10;
        int hjm3 = (bai += 5) % 10;
        int hjm4 = (qian += 5) % 10;
        String sum = "" + hjm1 + hjm2 + hjm3 + hjm4;
        System.out.println("新密钥" + "\t" + sum);
    }
}