import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Test37 {
    static Scanner sc = new Scanner(System.in);
    static Random rand = new Random();

    public static void main(String[] args) {
        int[] arr = createNumber();
//        System.out.println("当前数字生成组" + Arrays.toString(arr));
        int[] userArrays = userInputNumber();
//        System.out.println("当前用户输入的数组" + Arrays.toString(userArrays));
        int[] chaYan = panDuan(userArrays,arr);
        System.out.println("有红球" + chaYan[0] + "个");
        System.out.println("有蓝球" + chaYan[1] + "个");
        System.out.println();
        jiangjin(chaYan);

    sc.close();

    }

    public static void jiangjin(int[] arr){
        int red = arr[0];
        int blue = arr[1];
        if(red == 1 && blue == 1){
            System.out.println("中5元");
        }else if(red == 0 && blue == 1){
            System.out.println("中5元");
        }
        else if(red == 2 && blue == 1){
            System.out.println("中5元");
        }else if(red == 3 && blue == 1){
            System.out.println("中10元");
        }
        else if(red == 4 && blue == 0){
            System.out.println("中10元");
        }else if(red == 4 && blue == 1){
            System.out.println("中200元");
        }
        else if(red == 5 && blue == 0){
            System.out.println("中200元");
        }else if(red == 5 && blue == 1){
            System.out.println("中3000元");
        }else if(red == 6 && blue == 0){
            System.out.println("中500万元");
        }
        else if(red == 6 && blue == 1){
            System.out.println("中1000万元");
        }else {
            System.out.println("啥都没中");
        }
    }

    public static int[] panDuan(int[] a,int[] b){
        int[] arrs = new int[2];
        for(int i = 0;i < a.length - 1;i++){
            boolean flag = false;
            for(int j = 0;j < b.length - 1;j++){
                if(a[i] == b[j]){
                    flag = true;
                    break;
                }
            }
            if(flag){
                arrs[0]++;
            }
        }
        if(a[a.length - 1] == b[b.length - 1]){
            arrs[1]++;
        }
        return arrs;
    }

    public static int[] userInputNumber(){
        int[] arr = new int[7];
        for (int i = 0; i < arr.length - 1;) {
            System.out.println("请输入红色第" + (i + 1) + "个值");
            int Shuru = sc.nextInt();
            if(Shuru > 0 && Shuru < 34){
                boolean flag = contains(arr, Shuru,i);
                if (!flag) {
                    arr[i] = Shuru;
                    i++;
                }else {
                    System.out.println("该值重复,请重新输入");
                }
            }else {
                System.out.println("请输入1~33的数字!!!");
            }
        }
        while(true){
            System.out.println("请输入蓝色的值");
            int userblueInput = sc.nextInt();
            if (userblueInput > 0 && userblueInput < 17) {
                arr[arr.length - 1] = userblueInput;
                break;
            }else {
                System.out.println("请输入1~16的数字!!!");
            }
        }
        return arr;
    }

    public static int[] createNumber(){
        int[] arr = new int[7];
        for(int i=0;i < 6;){
            int redNumber = rand.nextInt(1,34);
            boolean flag = contains(arr,redNumber,i);
            if (!flag){
                arr[i] = redNumber;
                i++;
            }
        }
        int blueNumber = rand.nextInt(1,17);
        arr[arr.length - 1] = blueNumber;

        return arr;
    }

    public static boolean contains(int[] arr,int a,int b){
        for(int i = 0;i < b;i++){
            if(arr[i] == a){
                return true;
            }
        }
        return false;
    }
}