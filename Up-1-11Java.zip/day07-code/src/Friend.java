
public class Friend {
    // 创建一个类名字叫Friend(对象)
    private String name;
    private int age;
    // 封装name和age属性
    public Friend(){
        // 无参构造默认入口,第三方工具可以调用这个方法来创建对象
    }
    public Friend(String name, int age){
        // 有参数构造,允许在创建对象的时候完成属性的初始化赋值
        this.name = name;
        this.age = age;
        // age和name的值更新为当前提供的age,name形参值
    }
    public void Setname(String name){
        // 公开没有返回值的name方法设置器,外部调用时可以通过这个方法更新属性
        this.name = name;
    }
    public String Getname(){
        // 公开name访问器,外部调用可以访问当前保护的name属性
        return name;
    }
    public int Getage(){
        // 公开age访问器,外部调用可以访问当前保护的age属性
        return age;
    }
    public void Setage(int age){
        // 公开没有返回值的age方法设置器,外部调用时可以通过这个方法更新属性
        this.age = age;
    }
}