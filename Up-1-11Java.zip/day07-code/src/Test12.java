import java.util.Scanner;

public class Test12 {
    public static void main(String[] args) {
        hjm();
    }
    public static int[] hjm(){
        int[] arr = new int[6];
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < arr.length;) {
            System.out.println("输入分数");
            int sorce = sc.nextInt();
            if (sorce >= 0 && sorce <= 100) {
                arr[i] = sorce;
                i++;
            }
        }
        return arr;
    }
    public static int max(int[] arr){
        int max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
        return max;
    }
    public static int min(int[] arr){
        int min = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return min;
    }
}