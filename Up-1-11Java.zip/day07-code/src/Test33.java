import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
//  需求:创建两个随机数组(只准使用数组类型,方便后续拓展),red在1~33之间,blue在1~16之间,red数组拿6位不重复的数字,blue数组拿1位数字,用户输入userred看看能猜中red数组中多少个,blue同理.!只实现当前要求功能,其他暂且不用管

public class Test33 {
    static Random rand = new Random();
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        print();
        sc.close();
    }
    public static void print(){
        int[] red = red();
        int[] blue = blue();
        System.out.println(Arrays.toString(red));
        System.out.println(Arrays.toString(blue));

        int[] userred = new int[red.length];
        int[] userblue = new int[blue.length];
        System.out.println("输入红色号码");
        for(int i = 0; i < userred.length;){
            int shuru = sc.nextInt();
            if(shuru > 33 || shuru < 1){
                System.out.println("输入无效");
            } else if (pd(userred,shuru,i)) {
                System.out.println("输入重复数字");
            } else {
                userred[i] = shuru;
                System.out.println("输入成功");
                i++;
            }
        }

        System.out.println("输入蓝色号码");
        while(true){
            int shuru = sc.nextInt();
            if(shuru > 16 || shuru < 1){
                System.out.println("输入无效-请重新输入");
            }
            else {
                userblue[0] = shuru;
                break;
            }
        }
        int redcount = 0;
        int bluecount = 0;
        for(int i = 0; i < red.length; i++){
            for(int j = 0; j < red.length; j++){
                if(userred[i] == red[j]){
                    System.out.println(userred[i] + "中了");
                    redcount++;
                    break;
                }
            }
        }
        System.out.println("红色数中了" + redcount + "个");
        if(blue[0] == userblue[0]){
            bluecount++;
        }
        System.out.println("蓝色数中了" + bluecount + "个");

    }
    public static boolean pd(int[] arr, int n,int i){
        for(int j = 0; j < i; j++){
            if(arr[j] == n){
                return true;
            }
        }
        return false;
    }

    public static int[] red(){
        int[] arr = new int[6];
        int count = 0;
        while(count < 6){
            boolean flag = false;
            int a = rand.nextInt(1,34);
            for (int i = 0; i < count; i++) {
                if(a == arr[i]){
                    flag = true;
                    break;
                }
            }
            if(!flag){
                arr[count] = a;
                count++;
            }
        }
        return arr;
    }

    public static int[] blue (){
        return new int[]{rand.nextInt(1,17)};
    }
}