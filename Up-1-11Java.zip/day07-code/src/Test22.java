import java.util.Arrays;
import java.util.Random;

public class Test22 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = arr();
        for(int i = arr.length - 1;i > 0;i--){
            int a = rand.nextInt(i + 1);
            int temp = arr[i];
            arr[i] = arr[a];
            arr[a] = temp;
        }
        System.out.println(Arrays.toString(arr));
    }
    public static int[] arr(){
        return new int[]{2,588,888,1000,10000};
    }
}