public class PeopleTest {
    static int a = 10;
    public static void main(String[] args) {
        People p = new People();
        p.setName("小花");
        System.out.println(p.getName());
        People w = p;
        w.setName("小白");
        System.out.println(w.getName() + "," + p.getName());
        p = null;
//        System.out.println(p.getName());
        System.out.println(a);

    }
}