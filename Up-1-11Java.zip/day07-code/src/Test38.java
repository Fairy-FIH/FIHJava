import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Test38 {
    static Scanner sc = new Scanner(System.in);
    static Random rand = new Random();
    public static void main(String[] args) {
        Input();
        sc.close();
    }

    public static int[] End(int[] arr,int[] user){
        int length = 2 + (arr.length - 1);
        int[] end = new int[length];
        int count = 0;
        for(int i = 0;i < user.length - 1;i++){
            for(int j = 0;j < arr.length - 1;j++){
                if(user[i] == arr[j]){
                    end[0] += 1;
                    end[2 + count] = user[i];
                    count++;
                    break;
                }
            }
        }
        if(arr[arr.length - 1] == user[user.length - 1]){
            end[1] += 1;
        }
        return end;
    }

    public static void Input() {
        int[] arr = paiXusuanfa(arr());
        System.out.println(Arrays.toString(arr));
        int[] user = userinput();
        System.out.println(Arrays.toString(user));
        System.out.println();
        System.out.println("开始打印中奖数量!");
        int[] end = End(arr, user);
        System.out.println("红色中" + end[0] + "个" + "\n" + "蓝色中" + end[1] + "个");
        int width = end[0];
        System.out.println("中奖数字为:");
        int[] zhongjiang = danzishuprint(end);
        for(int i = 0;i < width;i++){
            System.out.println(zhongjiang[i]);
        }
        System.out.println();
        int[] zj = new int[2];
        zj[0] = end[0];
        zj[1] = end[1];
        jiangjin(zj);
    }

    public static void jiangjin(int[] arr){
        int red = arr[0];
        int blue = arr[1];
        if(red == 1 && blue == 1){
            System.out.println("中5元");
        }else if(red == 0 && blue == 1){
            System.out.println("中5元");
        }
        else if(red == 2 && blue == 1){
            System.out.println("中5元");
        }else if(red == 3 && blue == 1){
            System.out.println("中10元");
        }
        else if(red == 4 && blue == 0){
            System.out.println("中10元");
        }else if(red == 4 && blue == 1){
            System.out.println("中200元");
        }
        else if(red == 5 && blue == 0){
            System.out.println("中200元");
        }else if(red == 5 && blue == 1){
            System.out.println("中3000元");
        }else if(red == 6 && blue == 0){
            System.out.println("中500万元");
        }
        else if(red == 6 && blue == 1){
            System.out.println("中1000万元");
        }else {
            System.out.println("啥都没中");
        }
    }

    public static int[] danzishuprint(int[] arr){
        int[] endprint = new int[arr.length - 2];
        for(int i = 2;i < arr.length;i++){
            endprint[i - 2] = arr[i];
        }
        return endprint;
    }

    public static int[] paiXusuanfa(int[] arr){
        for(int i = 0;i < arr.length - 2;i++){
            for(int j = 0;j < arr.length - 2 - i;j++){
                if(arr[j] > arr[j+1]){
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
        return arr;
    }

    public static int[] userinput(){
        int[] arr = new int[7];
        for (int i = 0; i < arr.length - 1;) {
            System.out.println("红色第" + (i + 1) + "位:");
            int a = sc.nextInt();
            if (a > 33 || a < 1) {
                System.out.println("===输入值不合法,请重新输入===");
            }
            else {
                if (!panDuan(arr,a,i)){
                    System.out.println("输入成功!");
                    arr[i] = a;
                    System.out.println();
                    i++;
                }else {
                    System.out.println("===输入值重复===");
                }
            }
        }
        while (true){
            System.out.println("当前蓝色色位:");
            int b = sc.nextInt();
            if (b > 16 || b < 1) {
                System.out.println("===输入值不合法,请重新输入===");
            }else {
                arr[arr.length - 1] = b;
                System.out.println("输入成功!");
                break;
            }
        }
        return arr;
    }

    public static int[] arr(){
        int[] arr = new int[7];
        for (int i = 0; i < arr.length - 1;) {
            int shuZi = rand.nextInt(1,34);
            boolean flag = panDuan(arr,shuZi,i);
            if (!flag) {
                arr[i] = shuZi;
                i++;
            }
        }
        arr[arr.length - 1] = rand.nextInt(1,17);
        return arr;
    }
    public static boolean panDuan(int[] arr,int a,int b){
        for (int i = 0; i < b; i++) {
            if(arr[i] == a){
                return true;
            }
        }
        return false;
    }
}