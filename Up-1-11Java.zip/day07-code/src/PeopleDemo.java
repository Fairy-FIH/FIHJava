import java.util.Scanner;

public class PeopleDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        People[] p = new People[5];
        try {
            for (int i = 0; i < p.length; i++) {
                p[i] = new People();
                double x = p[i].drewCircle();
                System.out.println();
                System.out.println("第" + (i + 1) + "个人创建了半径为" + (String.format("%.2f",x)) + "的圆");
                System.out.println("其直径长度为" + (String.format("%.2f",p[i].getCirlezhijing())));
                System.out.println("面积为" + (String.format("%.2f",(3.14 * (x * x)))));
            }
        } finally {
            sc.close();
        }



    }
}