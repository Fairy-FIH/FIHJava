import java.util.Random;

public class Test27 {
    static Random rand = new Random();
    public static void main(String[] args) {
        int[] arr = new int[]{1,54,3,2,6,8,9,45,21};
        int[] newarr = new int[arr.length];
        for (int i = 0; i < newarr.length; ) {
            int x = rand.nextInt(arr.length);
            boolean zdl = pd(newarr,arr[x]);
            if(!zdl){
                // 哼!居然在新数组也找到你了!重新找,找到不一样的了再来找我!(返回true)
                // 欧耶!这次没在原数组找到一样的,给你带了个新的!(返回flase)
                // !居然是新的,来来来,我们交流交流
                newarr[i] = arr[x];
                // 欧克!居然新数组没你,那你就进来吧
                i++;
                // 自己加一次,欸嘿,等会儿再找一次
            }
        }



        for (int i = 0; i < newarr.length; i++) {
            System.out.print(newarr[i] + " ");
        }
    }
    public static boolean pd(int[] a,int b){
        for (int i = 0; i < a.length; i++) {
            if(a[i] == b){
                return true;
                // 找到啦,返回true
            }
        }
        return false;
        // 没找到耶,返回false
    }
}