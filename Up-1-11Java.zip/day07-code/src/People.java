import java.util.Random;

public class People {
    private Circle circle = new Circle();
    static Random rand = new Random();
    private String name;
    private int age;

    public People(){
    }
    public People(String name, int age,String circle) {
        this.name = name;
        this.age = age;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getName(){
        return name;

    }
    public int getAge(){
        return age;
    }
    public String circle(){
        return "画了一个圆";
    }
    public String eat(){
        return "正在吃饭";
    }
    public void sleep(){
        System.out.println("正在睡觉");
    }
    public double drewCircle(){
        double r = rand.nextDouble(0.3,11);
        circle.setBanjin(r);
        return r;
    }
    public double getCirlezhijing(){
        return circle.getZhijin();
    }

}