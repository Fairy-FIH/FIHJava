import java.util.Scanner;
public class Test3 {
    private static final Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        double originPrice = getOriginPrice();
        int month = getValidMonth();
        int cabinType = getValidCabinType();
        double finalPrice = calculateFinalPrice(originPrice, month, cabinType);
        printFinalPrice(finalPrice);
        sc.close();
    }
    private static double getOriginPrice() {
        System.out.print("请输入机票原价：");
        return sc.nextDouble();
    }
    private static int getValidMonth() {
        while (true) {
            System.out.print("请输入月份(1-12)：");
            int month = sc.nextInt();
            if (month >= 1 && month <= 12) return month;
            System.out.println("无效月份，请重新输入！");
        }
    }
    private static int getValidCabinType() {
        while (true) {
            System.out.print("选择舱位(1-头等舱/2-经济舱)：");
            int cabin = sc.nextInt();
            if (cabin == 1 || cabin == 2) return cabin;
            System.out.println("无效舱位，请重新输入！");
        }
    }
    private static double calculateFinalPrice(double origin, int month, int cabin) {
        boolean isPeak = month >= 5 && month <= 10;
        double discount = cabin == 1 ? (isPeak ? 0.9 : 0.7) : (isPeak ? 0.85 : 0.65);
        return origin * discount;
    }
    private static void printFinalPrice(double finalPrice) {
        System.out.printf("最终机票价格：%.2f 元%n", finalPrice);
    }
}