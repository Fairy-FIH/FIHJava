public class Phone {

    String Pingpai;
    double Jiage;

    public void call(){
        System.out.println("手机在打电话");

    }

    public void Playgeme(){
        System.out.println("手机在打游戏");
    }
}