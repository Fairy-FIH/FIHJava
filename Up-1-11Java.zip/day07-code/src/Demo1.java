import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.FlowLayout;
public class Demo1 {
    public static void main(String[] args) {
        // 创建 JFrame 实例
        JFrame frame = new JFrame("FlowLayout Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1280, 670);
        // 创建面板并设置其布局
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        // 向面板添加按钮
        panel.add(new JButton("Button 1"));
        panel.add(new JButton("Button 2"));
        panel.add(new JButton("Button 3"));
        // 将面板添加到窗口并显示
        frame.add(panel);
        frame.setVisible(true);
    }
}