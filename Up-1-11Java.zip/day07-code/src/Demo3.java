import java.util.Arrays;

public class Demo3 {
    public static void main(String[] args) {
//        int[][] arr = new int[][]{{22,66,44},{77,33,88},{25,45,65},{11,66,99}};
//        for (int i = 0; i < arr.length; i++) {
//            for (int j = 0; j < arr[i].length; j++) {
//                System.out.print(arr[i][j] + " ");
//            }
//            System.out.println();
//        }


//        int[] arr1 = new int[]{22,66,44};
//        int[] arr2 = new int[]{77,33,88};
//        int[] arr3 = new int[]{25,45,65};
//        int[] arr4 = new int[]{11,66,99};
//        int[][] number = {{arr1},{arr2},{arr3},{arr4}};
//        for(int[] num : number){
//            System.out.println(num);
//        }

//        int[][] arr = new int[3][3];
//        arr[1][1] = 9;
//        for (int i = 0; i < arr.length; i++) {
//            for (int j = 0; j < arr[i].length; j++) {
//                System.out.print(arr[i][j] + " ");
//            }
//            System.out.println();
//        }

        int[][] arr = new int[3][10];
        int[] arr1 = {11,22};
        int[] arr2 = {44,55,66};
//        for (int i = 0; i < arr.length; i++) {
//            for (int j = 0; j < arr[i].length; j++) {
//                System.out.print(arr[i][j] + " ");
//            }
//            System.out.println();
//        }

//        System.out.println("重新赋值:");
//        arr[0] = arr1;
//        arr[1] = arr2;
//        for (int i = 0; i < arr.length; i++) {
//            for (int j = 0; j < arr[i].length; j++) {
//                System.out.print(arr[i][j] + " ");
//            }
//            System.out.println();
//        }



    }
}